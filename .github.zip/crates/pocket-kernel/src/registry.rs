//! A tiny in-memory Windows CE registry.
//!
//! Pocket PC games keep more than preferences in `HKLM` / `HKCU`: the
//! CAB installer writes the paths a title later reads back to find its
//! own data. Astraware Bejeweled, for example, refuses to start (it
//! calls `ExitProcess(0x42)`) unless
//! `HKLM\SOFTWARE\Apps\Astraware Bejeweled\SaveDir` exists, because
//! that is where its `_setup.xml` told the installer to put saves.
//!
//! The store is deliberately simple:
//!
//! * Keys are canonical strings such as
//!   `HKLM\SOFTWARE\Apps\Astraware Bejeweled`, compared
//!   case-insensitively (WinCE registry keys are case-insensitive).
//! * Values are `REG_SZ`, `REG_DWORD` or `REG_BINARY`.
//! * `RegOpenKeyEx` hands out integer handles that map back to the
//!   canonical path, so `RegQueryValueEx` can resolve them without the
//!   guest holding a pointer into host memory.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Value types we model — the subset Pocket PC titles actually use.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum RegistryValue {
    /// `REG_SZ` (stored as UTF-8, handed to the guest as UTF-16).
    Sz(String),
    /// `REG_DWORD`.
    Dword(u32),
    /// `REG_BINARY`.
    Binary(Vec<u8>),
}

impl RegistryValue {
    /// The `REG_*` type code reported through `RegQueryValueEx`.
    pub fn type_code(&self) -> u32 {
        match self {
            RegistryValue::Sz(_) => 1,
            RegistryValue::Binary(_) => 3,
            RegistryValue::Dword(_) => 4,
        }
    }

    /// The value encoded exactly as the guest expects to receive it.
    pub fn to_bytes(&self) -> Vec<u8> {
        match self {
            RegistryValue::Sz(text) => text
                .encode_utf16()
                .chain(std::iter::once(0))
                .flat_map(u16::to_le_bytes)
                .collect(),
            RegistryValue::Dword(value) => value.to_le_bytes().to_vec(),
            RegistryValue::Binary(bytes) => bytes.clone(),
        }
    }
}

/// First handle handed out by [`Registry::open`]. Chosen to be
/// obviously not a predefined `HKEY_*` constant (`0x8000_000n`) and not
/// to collide with the VFS or GDI fake-handle ranges.
const HANDLE_BASE: u32 = 0xDEAD_9100;

#[derive(Debug, Default)]
pub(crate) struct RegistryStore {
    keys: HashMap<String, HashMap<String, RegistryValue>>,
    display: HashMap<String, String>,
    value_display: HashMap<String, HashMap<String, String>>,
    charge: Option<crate::memory_division::StoreCharge>,
    persistence: Option<std::path::PathBuf>,
}

#[derive(serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct RegistrySnapshot {
    version: u32,
    keys: HashMap<String, HashMap<String, RegistryValue>>,
    display: HashMap<String, String>,
    #[serde(default)]
    value_display: HashMap<String, HashMap<String, String>>,
}
#[derive(Debug, Default)]
pub struct Registry {
    store: Arc<Mutex<RegistryStore>>,
    /// Handles belong to a process; the values belong to the device.
    handles: HashMap<u32, String>,
    next_handle: u32,
    volatile_values: Arc<Mutex<HashMap<(String, String), Option<RegistryValue>>>>,
}

/// Map a predefined `HKEY_*` constant to its canonical prefix.
fn root_prefix(root: u32) -> Option<&'static str> {
    match root {
        0x8000_0000 => Some("HKCR"),
        0x8000_0001 => Some("HKCU"),
        0x8000_0002 => Some("HKLM"),
        0x8000_0003 => Some("HKU"),
        _ => None,
    }
}

/// Normalise the textual form of a key path: single backslashes, no
/// leading or trailing separator, `HKEY_LOCAL_MACHINE` style prefixes
/// folded to the short form used internally.
pub fn canonical_key(path: &str) -> String {
    let mut parts: Vec<&str> = path
        .split('\\')
        .map(str::trim)
        .filter(|part| !part.is_empty())
        .collect();
    if let Some(first) = parts.first_mut() {
        *first = match first.to_ascii_uppercase().as_str() {
            "HKEY_CLASSES_ROOT" => "HKCR",
            "HKEY_CURRENT_USER" => "HKCU",
            "HKEY_LOCAL_MACHINE" => "HKLM",
            "HKEY_USERS" => "HKU",
            _ => *first,
        };
    }
    parts.join("\\")
}

impl Registry {
    /// Independent values for a bounded CAB setup transaction. No live handles,
    /// persistence target or object-store charge escape into the helper process.
    pub fn isolated_copy(&self) -> Self {
        let store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        Self {
            store: Arc::new(Mutex::new(RegistryStore {
                keys: store.keys.clone(),
                display: store.display.clone(),
                value_display: store.value_display.clone(),
                charge: None,
                persistence: None,
            })),
            handles: HashMap::new(),
            next_handle: HANDLE_BASE,
            volatile_values: Arc::new(Mutex::new(
                self.volatile_values
                    .lock()
                    .unwrap_or_else(|e| e.into_inner())
                    .clone(),
            )),
        }
    }

    /// Commit only the setup's delta, atomically, preserving concurrent device
    /// values. A conflicting write or quota failure leaves the live store intact.
    pub fn commit_isolated(&mut self, baseline: &Self, staged: &Self) -> bool {
        if Arc::ptr_eq(&self.store, &staged.store)
            || Arc::ptr_eq(&self.store, &baseline.store)
            || Arc::ptr_eq(&baseline.store, &staged.store)
        {
            return false;
        }
        let baseline = baseline.store.lock().unwrap_or_else(|e| e.into_inner());
        let staged = staged.store.lock().unwrap_or_else(|e| e.into_inner());
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let mut keys = store.keys.clone();
        for key in baseline.keys.keys().chain(staged.keys.keys()) {
            let before = baseline.keys.get(key);
            let after = staged.keys.get(key);
            // This transaction API supports value changes and key creation;
            // deleting whole keys is deliberately outside the setup profile.
            if after.is_none() {
                return false;
            }
            let dest = keys.entry(key.clone()).or_default();
            for name in before
                .into_iter()
                .flat_map(|v| v.keys())
                .chain(after.into_iter().flat_map(|v| v.keys()))
            {
                let old = before.and_then(|v| v.get(name));
                let new = after.and_then(|v| v.get(name));
                if old == new {
                    continue;
                }
                // Compare against live, not the delta already applied above.
                if store.keys.get(key).and_then(|v| v.get(name)) != old {
                    return false;
                }
                if let Some(value) = new {
                    dest.insert(name.clone(), value.clone());
                } else {
                    dest.remove(name);
                }
            }
        }
        if store
            .charge
            .as_mut()
            .is_some_and(|charge| !charge.resize(Self::stored_pages(&keys)))
        {
            return false;
        }
        store.keys = keys;
        let live = store.keys.clone();
        store.value_display.retain(|key, names| {
            names.retain(|name, _| live.get(key).is_some_and(|v| v.contains_key(name)));
            !names.is_empty()
        });
        for (key, names) in &staged.value_display {
            for (name, display) in names {
                if live.get(key).is_some_and(|v| v.contains_key(name)) {
                    store
                        .value_display
                        .entry(key.clone())
                        .or_default()
                        .entry(name.clone())
                        .or_insert_with(|| display.clone());
                }
            }
        }
        for (key, display) in &staged.display {
            store
                .display
                .entry(key.clone())
                .or_insert_with(|| display.clone());
        }
        true
    }

    /// Load only device values. Process handles and RAM charges never go on disk.
    /// A corrupt snapshot is an error, so a later flush cannot overwrite it.
    pub fn configure_persistence(&mut self, path: &std::path::Path) -> std::io::Result<()> {
        use std::io::{Error, ErrorKind, Read};
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        if let Some(existing) = &store.persistence {
            return if existing == path {
                Ok(())
            } else {
                Err(Error::new(
                    ErrorKind::InvalidInput,
                    "registry already attached to another device",
                ))
            };
        }
        let snapshot = match std::fs::File::open(path) {
            Ok(file) => {
                let mut bytes = Vec::new();
                file.take(64 * 1024 * 1024 + 1).read_to_end(&mut bytes)?;
                if bytes.len() > 64 * 1024 * 1024 {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        "registry snapshot too large",
                    ));
                }
                let snapshot: RegistrySnapshot = serde_json::from_slice(&bytes)
                    .map_err(|e| Error::new(ErrorKind::InvalidData, e))?;
                if snapshot.version != 1
                    || snapshot
                        .keys
                        .keys()
                        .any(|k| canonical_key(k).to_ascii_lowercase() != *k)
                    || snapshot
                        .keys
                        .values()
                        .any(|v| v.keys().any(|k| k.to_ascii_lowercase() != *k))
                {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        "invalid registry snapshot version or key",
                    ));
                }
                if snapshot.value_display.iter().any(|(key, names)| {
                    !snapshot.keys.contains_key(key)
                        || names.iter().any(|(name, display)| {
                            display.to_ascii_lowercase() != *name
                                || !snapshot.keys[key].contains_key(name)
                        })
                }) {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        "invalid registry value spelling",
                    ));
                }
                Some(snapshot)
            }
            Err(e) if e.kind() == ErrorKind::NotFound => None,
            Err(e) => return Err(e),
        };
        if let Some(snapshot) = snapshot {
            let mut keys = store.keys.clone();
            for (key, mut values) in snapshot.keys {
                // Old snapshots may contain an empty backlight key or a zero
                // left by an uninitialised game setting. Repair device defaults
                // before Colors queries them to initialise its own slider.
                if key == r"hkcu\controlpanel\backlight" && store.keys.contains_key(&key) {
                    for name in ["level", "onlevel"] {
                        if !matches!(values.get(name), Some(RegistryValue::Dword(1..=31))) {
                            values.insert(name.into(), RegistryValue::Dword(11));
                        }
                    }
                    values
                        .entry("dimlevel".into())
                        .or_insert(RegistryValue::Dword(0));
                }
                keys.insert(key, values);
            }
            // Older snapshots can contain a child without its parent. CAB
            // seeding skips values already persisted, so reinstalling cannot
            // repair that topology. Restore the registry invariant on load,
            // before charging/publishing the merged transaction.
            let mut parent_display = HashMap::new();
            for key in keys.keys().cloned().collect::<Vec<_>>() {
                let spelling = snapshot
                    .display
                    .get(&key)
                    .or_else(|| store.display.get(&key))
                    .unwrap_or(&key);
                for (end, _) in key.match_indices('\\') {
                    let parent = key[..end].to_string();
                    keys.entry(parent.clone()).or_default();
                    // Saved display spelling need not have the same UTF-8
                    // byte length as its canonical lowercase key.
                    let depth = parent.split('\\').count();
                    parent_display.entry(parent).or_insert_with(|| {
                        spelling
                            .split('\\')
                            .take(depth)
                            .collect::<Vec<_>>()
                            .join("\\")
                    });
                }
            }
            if store
                .charge
                .as_mut()
                .is_some_and(|charge| !charge.resize(Self::stored_pages(&keys)))
            {
                return Err(Error::other("insufficient device RAM for registry"));
            }
            store.keys = keys;
            for (key, spelling) in parent_display {
                store.display.entry(key).or_insert(spelling);
            }
            store.display.extend(snapshot.display);
            store.value_display.extend(snapshot.value_display);
        }
        store.persistence = Some(path.to_owned());
        Ok(())
    }

    /// Start a Gizmondo game at the second brightness notch, overriding
    /// values persisted by the preceding game. Call after loading persistence,
    /// once for the root launch; child processes inherit the live settings.
    pub fn reset_gizmondo_backlight(&mut self) -> std::io::Result<()> {
        for (name, value) in [("Level", 11), ("OnLevel", 11), ("DimLevel", 0)] {
            if !self.set_value(
                r"HKCU\ControlPanel\Backlight",
                name,
                RegistryValue::Dword(value),
            ) {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::OutOfMemory,
                    "Cannot reset Gizmondo backlight in the device registry",
                ));
            }
        }
        self.flush()
    }

    /// Publish a complete snapshot using a temporary file on the same volume.
    /// Keep the previous snapshot intact if writing or renaming fails.
    pub fn flush(&self) -> std::io::Result<()> {
        use std::io::Write;
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        let store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let Some(path) = &store.persistence else {
            return Ok(());
        };
        let snapshot = RegistrySnapshot {
            version: 1,
            keys: store.keys.clone(),
            display: store.display.clone(),
            value_display: store.value_display.clone(),
        };
        let bytes = serde_json::to_vec(&snapshot).map_err(std::io::Error::other)?;
        let temp = path.with_extension(format!(
            "tmp-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ));
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp)?;
        let result = (|| {
            file.write_all(&bytes)?;
            file.sync_all()?;
            drop(file);
            std::fs::rename(&temp, path)
        })();
        if result.is_err() {
            let _ = std::fs::remove_file(&temp);
        }
        result
    }

    pub fn new() -> Self {
        Self {
            store: Arc::new(Mutex::new(RegistryStore::default())),
            handles: HashMap::new(),
            next_handle: HANDLE_BASE,
            volatile_values: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// A registry pre-populated the way a Pocket PC device would be.
    ///
    /// `HKCU\ControlPanel\Owner` exists on every device (the "Owner
    /// Information" control panel), and games read the owner name to
    /// personalise menus. MetalStrike additionally reads its own
    /// licence pair, which earlier work established as `1739` / `0`.
    /// The `Drivers\BuiltIn` entries describe hardware the emulated
    /// device claims to have; a title that polls for a missing driver
    /// tends to give up and exit rather than fall back.
    pub fn with_device_defaults() -> Self {
        let mut reg = Self::new();
        // Gizmondo OEMINC.H: range 1..31. Neutral is Colors slider position 2,
        // OnLevel 11 / DimLevel 0 (SDK hardware default is 24). Colors reads
        // OnLevel to initialise its own brightness slider, then writes both
        // OnLevel and DimLevel and signals BackLightChangeEvent.
        for (name, value) in [("Level", 11), ("OnLevel", 11), ("DimLevel", 0)] {
            reg.set_value(
                r"HKCU\ControlPanel\Backlight",
                name,
                RegistryValue::Dword(value),
            );
        }
        reg.set_value(
            r"HKCU\ControlPanel\Owner",
            "Owner",
            RegistryValue::Sz("Argon".to_string()),
        );
        reg.set_value(
            r"HKLM\SOFTWARE\Greatelsoft.Com\MetalStrike",
            "SN-Key1",
            RegistryValue::Dword(1739),
        );
        reg.set_value(
            r"HKLM\SOFTWARE\Greatelsoft.Com\MetalStrike",
            "SN-Key2",
            RegistryValue::Dword(0),
        );
        // The emulated NMEA serial bridge is a real stream-interface device.
        // WinCE applications enumerate Drivers\Active and follow Key to its
        // configuration before attempting CreateFileW(COM8:). Both device
        // profiles use these defaults; GPS access still obeys Service::allowed.
        reg.create_key(r"HKLM\Drivers\Active");
        reg.create_key(r"HKLM\Drivers\BuiltIn");
        let serial_key = r"Drivers\BuiltIn\Serial8";
        reg.set_value(
            r"HKLM\Drivers\Active\08",
            "Name",
            RegistryValue::Sz("COM8:".into()),
        );
        reg.set_value(
            r"HKLM\Drivers\Active\08",
            "Key",
            RegistryValue::Sz(serial_key.into()),
        );
        reg.set_value(
            &format!(r"HKLM\{serial_key}"),
            "Prefix",
            RegistryValue::Sz("COM".into()),
        );
        reg.set_value(
            &format!(r"HKLM\{serial_key}"),
            "Index",
            RegistryValue::Dword(8),
        );
        reg.set_value(
            &format!(r"HKLM\{serial_key}"),
            "FriendlyName",
            RegistryValue::Sz("PocketHLE NMEA GPS".into()),
        );

        // The g-sensor. Tilt-controlled titles find the accelerometer by
        // opening its driver key rather than by asking a sensor API, so
        // a device without this key reads as a device without a sensor —
        // Xtrakt polls for it (`RegOpenKeyEx`, `Sleep(10)`, retry) and
        // shuts down when the retries run out.
        //
        // `poll_delay` is the sampling interval in milliseconds and
        // `resolution` the counts-per-g the driver reports; both are the
        // values shipped on the HTC handsets these games targeted.
        reg.set_value(
            r"HKLM\Drivers\BuiltIn\Accelerometer",
            "poll_delay",
            RegistryValue::Dword(20),
        );
        reg.set_value(
            r"HKLM\Drivers\BuiltIn\Accelerometer",
            "resolution",
            RegistryValue::Dword(1000),
        );
        // Which way up the driver currently believes the device is.
        // `0` is the unrotated portrait orientation, which is what an
        // emulated screen always is.
        reg.set_value(
            r"HKLM\Drivers\BuiltIn\Accelerometer",
            "current_rotation",
            RegistryValue::Dword(0),
        );
        // The companion screen-rotation service. A game that rotates
        // itself reads `OverrideCounter` to suppress the shell's own
        // auto-rotation while it is in the foreground; zero means
        // nothing is currently overriding it.
        reg.set_value(
            r"HKLM\Services\MultiService\mods\Rotation",
            "OverrideCounter",
            RegistryValue::Dword(0),
        );
        reg
    }

    /// Resolve the `(root, subkey)` pair a `Reg*` call was given.
    ///
    /// `root` is either a predefined `HKEY_*` constant or a handle we
    /// previously returned from [`Registry::open`], which is how games
    /// walk down a tree one level at a time.
    pub fn resolve(&self, root: u32, subkey: &str) -> Option<String> {
        let base = match root_prefix(root) {
            Some(prefix) => prefix.to_string(),
            None => self.handles.get(&root)?.clone(),
        };
        let sub = canonical_key(subkey);
        if sub.is_empty() {
            Some(canonical_key(&base))
        } else {
            Some(canonical_key(&format!("{base}\\{sub}")))
        }
    }

    pub fn contains_key(&self, path: &str) -> bool {
        let key = canonical_key(path).to_ascii_lowercase();
        if self
            .store
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .keys
            .contains_key(&key)
        {
            return true;
        }
        let prefix = format!("{key}\\");
        self.volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .keys()
            .any(|(path, _)| path == &key || path.starts_with(&prefix))
    }

    fn stored_pages(keys: &HashMap<String, HashMap<String, RegistryValue>>) -> u32 {
        let mut bytes = 0u64;
        for (key, values) in keys {
            bytes += (key.encode_utf16().count() as u64 + 1) * 2;
            for (name, value) in values {
                bytes += (name.encode_utf16().count() as u64 + 1) * 2
                    + 4
                    + value.to_bytes().len() as u64;
            }
        }
        crate::memory_division::pages(bytes)
    }
    pub fn attach_ram(&mut self, ram: Option<&crate::memory_division::MemoryDivision>) -> bool {
        let Some(ram) = ram else {
            let current = self.store.lock().unwrap_or_else(|e| e.into_inner());
            let store = RegistryStore {
                keys: current.keys.clone(),
                display: current.display.clone(),
                value_display: current.value_display.clone(),
                charge: None,
                persistence: current.persistence.clone(),
            };
            drop(current);
            self.store = Arc::new(Mutex::new(store));
            return true;
        };
        if Arc::ptr_eq(&self.store, &ram.registry) {
            return true;
        }
        let current = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let mut target = ram.registry.lock().unwrap_or_else(|e| e.into_inner());
        let mut keys = target.keys.clone();
        // A child's boot defaults must not overwrite the launcher's live
        // registry. Explicit frontend settings are written after attachment.
        for (key, values) in &current.keys {
            let dest = keys.entry(key.clone()).or_default();
            for (name, value) in values {
                dest.entry(name.clone()).or_insert_with(|| value.clone());
            }
        }
        let pages = Self::stored_pages(&keys);
        if let Some(charge) = &mut target.charge {
            if !charge.resize(pages) {
                return false;
            }
        } else {
            let Some(charge) = ram.store_charge(pages) else {
                return false;
            };
            target.charge = Some(charge);
        }
        target.keys = keys;
        for (key, name) in &current.display {
            target
                .display
                .entry(key.clone())
                .or_insert_with(|| name.clone());
        }
        for (key, names) in &current.value_display {
            for (name, display) in names {
                target
                    .value_display
                    .entry(key.clone())
                    .or_default()
                    .entry(name.clone())
                    .or_insert_with(|| display.clone());
            }
        }
        drop(target);
        drop(current);
        self.store = ram.registry.clone();
        true
    }
    pub fn create_key(&mut self, path: &str) -> bool {
        if self.contains_key(path) {
            return true;
        }
        let canonical = canonical_key(path);
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let ancestors: Vec<_> = canonical
            .match_indices('\\')
            .map(|(end, _)| canonical[..end].to_string())
            .chain(std::iter::once(canonical.clone()))
            .collect();
        let mut keys = store.keys.clone();
        for key in &ancestors {
            keys.entry(key.to_ascii_lowercase()).or_default();
        }
        if store
            .charge
            .as_mut()
            .is_some_and(|charge| !charge.resize(Self::stored_pages(&keys)))
        {
            return false;
        }
        for key in ancestors {
            store.display.entry(key.to_ascii_lowercase()).or_insert(key);
        }
        store.keys = keys;
        true
    }
    /// Process/game view only. Flush serializes the device store, never these values.
    pub fn set_volatile_value(&mut self, path: &str, name: &str, value: RegistryValue) {
        self.volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .insert(
                (
                    canonical_key(path).to_ascii_lowercase(),
                    name.to_ascii_lowercase(),
                ),
                Some(value),
            );
    }
    pub fn set_value(&mut self, path: &str, name: &str, value: RegistryValue) -> bool {
        let view_key = (
            canonical_key(path).to_ascii_lowercase(),
            name.to_ascii_lowercase(),
        );
        {
            let mut overlay = self
                .volatile_values
                .lock()
                .unwrap_or_else(|e| e.into_inner());
            if let Some(existing) = overlay.get_mut(&view_key) {
                *existing = Some(value);
                return true;
            }
        }
        let canonical = canonical_key(path);
        let lower = canonical.to_ascii_lowercase();
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let ancestors: Vec<_> = canonical
            .match_indices('\\')
            .map(|(end, _)| canonical[..end].to_string())
            .chain(std::iter::once(canonical.clone()))
            .collect();
        let mut keys = store.keys.clone();
        for key in &ancestors {
            keys.entry(key.to_ascii_lowercase()).or_default();
        }
        keys.entry(lower.clone())
            .or_default()
            .insert(name.to_ascii_lowercase(), value);
        if store
            .charge
            .as_mut()
            .is_some_and(|charge| !charge.resize(Self::stored_pages(&keys)))
        {
            return false;
        }
        store
            .value_display
            .entry(lower.clone())
            .or_default()
            .entry(name.to_ascii_lowercase())
            .or_insert_with(|| name.to_string());
        for key in ancestors {
            store.display.entry(key.to_ascii_lowercase()).or_insert(key);
        }
        store.keys = keys;
        true
    }
    pub fn value(&self, path: &str, name: &str) -> Option<RegistryValue> {
        if let Some(value) = self
            .volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .get(&(
                canonical_key(path).to_ascii_lowercase(),
                name.to_ascii_lowercase(),
            ))
        {
            return value.clone();
        }
        self.store
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .keys
            .get(&canonical_key(path).to_ascii_lowercase())?
            .get(&name.to_ascii_lowercase())
            .cloned()
    }
    /// Values in stable case-insensitive order, retaining the original spelling.
    /// Old snapshots with normalized names use that existing spelling.
    pub fn values(&self, path: &str) -> Vec<(String, RegistryValue)> {
        let key = canonical_key(path).to_ascii_lowercase();
        let mut result = std::collections::BTreeMap::new();
        {
            let store = self.store.lock().unwrap_or_else(|e| e.into_inner());
            if let Some(values) = store.keys.get(&key) {
                for (name, value) in values {
                    let display = store
                        .value_display
                        .get(&key)
                        .and_then(|n| n.get(name))
                        .unwrap_or(name)
                        .clone();
                    result.insert(name.clone(), (display, value.clone()));
                }
            }
        }
        for ((path, name), value) in self
            .volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .iter()
        {
            if path == &key {
                match value {
                    Some(value) => {
                        let display = result
                            .get(name)
                            .map(|p: &(String, RegistryValue)| p.0.clone())
                            .unwrap_or_else(|| name.clone());
                        result.insert(name.clone(), (display, value.clone()));
                    }
                    None => {
                        result.remove(name);
                    }
                }
            }
        }
        result.into_values().collect()
    }
    /// Immediate children, sorted case-insensitively with their display names.
    pub fn subkeys(&self, path: &str) -> Vec<String> {
        let prefix = format!("{}\\", canonical_key(path).to_ascii_lowercase());
        let store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let mut children = std::collections::BTreeMap::new();
        for key in store.keys.keys() {
            if let Some(rest) = key.strip_prefix(&prefix) {
                if let Some(child) = rest.split('\\').next().filter(|s| !s.is_empty()) {
                    let display = store
                        .display
                        .get(key)
                        .and_then(|s| s.get(prefix.len()..))
                        .and_then(|s| s.split('\\').next())
                        .unwrap_or(child);
                    children
                        .entry(child.to_string())
                        .or_insert_with(|| display.to_string());
                }
            }
        }
        for (key, _) in self
            .volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .keys()
        {
            if let Some(rest) = key.strip_prefix(&prefix) {
                if let Some(child) = rest.split('\\').next().filter(|s| !s.is_empty()) {
                    children.entry(child.into()).or_insert_with(|| child.into());
                }
            }
        }
        children.into_values().collect()
    }

    /// CE deletes a leaf key with its values; children and open target handles
    /// must be closed/removed by the caller first. Errors are Win32 status codes.
    pub fn delete_key(&mut self, root: u32, subkey: &str) -> Result<(), u32> {
        if canonical_key(subkey).is_empty() {
            return Err(87);
        }
        let path = self.resolve(root, subkey).ok_or(6u32)?;
        let key = path.to_ascii_lowercase();
        let prefix = format!("{key}\\");
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let mut volatile = self
            .volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        if !store.keys.contains_key(&key)
            && !volatile
                .keys()
                .any(|(path, _)| path == &key || path.starts_with(&prefix))
        {
            return Err(2);
        }
        if store.keys.keys().any(|path| path.starts_with(&prefix))
            || volatile.keys().any(|(path, _)| path.starts_with(&prefix))
            || self
                .handles
                .values()
                .any(|path| path.eq_ignore_ascii_case(&key))
        {
            return Err(5);
        }
        store.keys.remove(&key);
        store.display.remove(&key);
        store.value_display.remove(&key);
        volatile.retain(|(path, _), _| path != &key);
        let pages = Self::stored_pages(&store.keys);
        if let Some(charge) = &mut store.charge {
            charge.resize(pages);
        }
        Ok(())
    }

    pub fn delete_value(&mut self, path: &str, name: &str) -> bool {
        if let Some(value) = self
            .volatile_values
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .get_mut(&(
                canonical_key(path).to_ascii_lowercase(),
                name.to_ascii_lowercase(),
            ))
        {
            return value.take().is_some();
        }
        let mut store = self.store.lock().unwrap_or_else(|e| e.into_inner());
        let removed = store
            .keys
            .get_mut(&canonical_key(path).to_ascii_lowercase())
            .and_then(|values| values.remove(&name.to_ascii_lowercase()))
            .is_some();
        if removed {
            if let Some(names) = store
                .value_display
                .get_mut(&canonical_key(path).to_ascii_lowercase())
            {
                names.remove(&name.to_ascii_lowercase());
            }
            let pages = Self::stored_pages(&store.keys);
            if let Some(charge) = &mut store.charge {
                charge.resize(pages);
            }
        }
        removed
    }

    /// Hand out a handle for an existing key. Returns `None` when the
    /// key was never created, so `RegOpenKeyEx` can report
    /// `ERROR_FILE_NOT_FOUND` the way a real device does.
    pub fn open(&mut self, path: &str) -> Option<u32> {
        let lower = canonical_key(path).to_ascii_lowercase();
        if !self.contains_key(path) {
            return None;
        }
        let handle = self.next_handle;
        self.next_handle = self.next_handle.wrapping_add(1);
        self.handles.insert(handle, lower);
        Some(handle)
    }

    /// Create the key if needed, then hand out a handle for it.
    pub fn create_and_open(&mut self, path: &str) -> u32 {
        if !self.create_key(path) {
            return 0;
        }
        self.open(path).unwrap_or(0)
    }

    pub fn path_for(&self, handle: u32) -> Option<String> {
        if let Some(prefix) = root_prefix(handle) {
            return Some(prefix.to_string());
        }
        self.handles.get(&handle).cloned()
    }

    pub fn close(&mut self, handle: u32) {
        self.handles.remove(&handle);
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn persisted_orphan_keys_restore_parent_enumeration_without_changing_values() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let child = r"hklm\software\example\packs\default";
        let snapshot = RegistrySnapshot {
            version: 1,
            keys: HashMap::from([(
                child.into(),
                HashMap::from([
                    ("title".into(), RegistryValue::Sz("Saved title".into())),
                    ("progress".into(), RegistryValue::Dword(42)),
                ]),
            )]),
            display: HashMap::from([(child.into(), r"HKLM\Software\Example\Packs\Default".into())]),
            value_display: HashMap::from([(
                child.into(),
                HashMap::from([
                    ("title".into(), "Title".into()),
                    ("progress".into(), "Progress".into()),
                ]),
            )]),
        };
        std::fs::write(&path, serde_json::to_vec(&snapshot).unwrap()).unwrap();
        let mut registry = Registry::new();
        registry.configure_persistence(&path).unwrap();
        assert!(registry.open(r"HKLM\Software\Example\Packs").is_some());
        assert_eq!(registry.subkeys(r"HKLM\Software\Example"), vec!["Packs"]);
        assert_eq!(
            registry.subkeys(r"HKLM\Software\Example\Packs"),
            vec!["Default"]
        );
        assert_eq!(
            registry.value(child, "Progress"),
            Some(RegistryValue::Dword(42))
        );
        assert_eq!(
            registry.value(child, "TITLE"),
            Some(RegistryValue::Sz("Saved title".into()))
        );
        registry.flush().unwrap();
        let mut again = Registry::new();
        again.configure_persistence(&path).unwrap();
        assert_eq!(
            again.subkeys(r"HKLM\Software\Example\Packs"),
            vec!["Default"]
        );
        assert_eq!(again.values(child), registry.values(child));
    }

    #[test]
    fn enumerated_value_spelling_survives_case_insensitive_updates_and_persistence() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let mut registry = Registry::new();
        registry.configure_persistence(&path).unwrap();
        assert!(registry.set_value("HKCU\\Example", "MiXeD🧭", RegistryValue::Dword(1)));
        assert!(registry.set_value("hkcu\\example", "mixed🧭", RegistryValue::Dword(2)));
        assert_eq!(
            registry.values("HKCU\\EXAMPLE"),
            vec![("MiXeD🧭".into(), RegistryValue::Dword(2))]
        );
        registry.flush().unwrap();
        let mut reloaded = Registry::new();
        reloaded.configure_persistence(&path).unwrap();
        assert_eq!(
            reloaded.values("HKCU\\Example"),
            registry.values("HKCU\\Example")
        );
        let baseline = reloaded.isolated_copy();
        let mut staged = baseline.isolated_copy();
        staged.set_value("HKCU\\Example", "Added", RegistryValue::Dword(3));
        staged.delete_value("HKCU\\Example", "mixed🧭");
        assert!(reloaded.commit_isolated(&baseline, &staged));
        assert_eq!(
            reloaded.values("HKCU\\Example"),
            vec![("Added".into(), RegistryValue::Dword(3))]
        );
        reloaded.flush().unwrap();
        let mut again = Registry::new();
        again.configure_persistence(&path).unwrap();
        assert_eq!(
            again.values("HKCU\\Example"),
            reloaded.values("HKCU\\Example")
        );
    }

    #[test]
    fn cab_setup_transaction_isolated_delta_conflict_and_quota() {
        let ram = crate::memory_division::MemoryDivision::new(32 * 1024 * 1024, 4096).unwrap();
        let mut live = Registry::new();
        assert!(live.attach_ram(Some(&ram)));
        assert!(live.set_value("HKCU\\Setup", "old", RegistryValue::Dword(7)));
        let handle = live.open("HKCU\\Setup").unwrap();
        let baseline = live.isolated_copy();
        let mut staged = baseline.isolated_copy();
        assert!(staged.set_value("HKCU\\Setup", "new", RegistryValue::Binary(vec![1; 16])));
        assert_eq!(live.value("HKCU\\Setup", "new"), None);
        live.set_value("HKCU\\Other", "concurrent", RegistryValue::Dword(9));
        assert!(live.commit_isolated(&baseline, &staged));
        assert_eq!(
            live.value("HKCU\\Other", "concurrent"),
            Some(RegistryValue::Dword(9))
        );
        assert_eq!(live.path_for(handle).as_deref(), Some("hkcu\\setup"));
        let baseline = live.isolated_copy();
        let mut staged = baseline.isolated_copy();
        staged.set_value("HKCU\\Setup", "old", RegistryValue::Dword(8));
        live.set_value("HKCU\\Setup", "old", RegistryValue::Dword(10));
        assert!(!live.commit_isolated(&baseline, &staged));
        assert_eq!(
            live.value("HKCU\\Setup", "old"),
            Some(RegistryValue::Dword(10))
        );
        let baseline = live.isolated_copy();
        let mut staged = baseline.isolated_copy();
        staged.set_value(
            "HKCU\\Setup",
            "huge",
            RegistryValue::Binary(vec![0; 32 * 1024 * 1024]),
        );
        let used = ram.snapshot().store_used;
        assert!(!live.commit_isolated(&baseline, &staged));
        assert_eq!(live.value("HKCU\\Setup", "huge"), None);
        assert_eq!(ram.snapshot().store_used, used);
    }

    #[test]
    fn nmea_serial_device_is_discoverable_in_both_persistent_profiles() {
        let dir = tempfile::tempdir().unwrap();
        for profile in ["registry-pocketpc.json", "registry-gizmondo.json"] {
            let path = dir.path().join(profile);
            let mut old = Registry::new();
            old.configure_persistence(&path).unwrap();
            old.set_value(r"HKCU\User", "Choice", RegistryValue::Dword(42));
            old.flush().unwrap();
            let mut registry = Registry::with_device_defaults();
            registry.configure_persistence(&path).unwrap();
            assert!(registry.open(r"HKLM\Drivers\Active").is_some());
            assert_eq!(registry.subkeys(r"HKLM\Drivers\Active"), vec!["08"]);
            assert_eq!(
                registry.value(r"HKLM\Drivers\Active\08", "Name"),
                Some(RegistryValue::Sz("COM8:".into()))
            );
            assert_eq!(
                registry.value(r"HKLM\Drivers\Active\08", "Key"),
                Some(RegistryValue::Sz(r"Drivers\BuiltIn\Serial8".into()))
            );
            assert_eq!(
                registry.value(r"HKLM\Drivers\BuiltIn\Serial8", "Index"),
                Some(RegistryValue::Dword(8))
            );
            assert_eq!(
                registry.value(r"HKCU\User", "Choice"),
                Some(RegistryValue::Dword(42))
            );
            registry.flush().unwrap();
        }
    }

    #[test]
    fn gizmondo_backlight_second_position_defaults_are_queryable() {
        let registry = super::Registry::with_device_defaults();
        assert_eq!(
            registry.value(r"HKCU\ControlPanel\Backlight", "OnLevel"),
            Some(super::RegistryValue::Dword(11))
        );
        assert_eq!(
            registry.value(r"HKCU\ControlPanel\Backlight", "DimLevel"),
            Some(super::RegistryValue::Dword(0))
        );
    }

    use super::*;

    #[test]
    fn memory_division_registry_changes_obey_store_capacity() {
        let ram = crate::memory_division::MemoryDivision::new(64 * 4096, 8).unwrap();
        let mut registry = Registry::new();
        assert!(registry.attach_ram(Some(&ram)));
        assert!(registry.set_value("HKCU\\Test", "value", RegistryValue::Binary(vec![9; 4096])));
        let used = ram.snapshot().store_used;
        assert!(!registry.set_value(
            "HKCU\\Test",
            "value",
            RegistryValue::Binary(vec![7; 8 * 4096])
        ));
        assert_eq!(ram.snapshot().store_used, used);
        assert_eq!(
            registry.value("HKCU\\Test", "value"),
            Some(RegistryValue::Binary(vec![9; 4096]))
        );
        assert!(registry.delete_value("HKCU\\Test", "value"));
        assert!(ram.snapshot().store_used < used);
        let mut child = Registry::new();
        assert!(child.attach_ram(Some(&ram)));
        assert_eq!(ram.snapshot().store_used, 1);
        assert!(child.set_value("HKCU\\Test", "shared", RegistryValue::Dword(42)));
        assert_eq!(
            registry.value("HKCU\\Test", "shared"),
            Some(RegistryValue::Dword(42))
        );
        drop(registry);
        assert_eq!(ram.snapshot().store_used, 1); // object store outlives a process
    }

    #[test]
    fn backlight_persistence_repairs_invalid_defaults_and_preserves_valid_choices() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let key = r"HKCU\ControlPanel\Backlight";
        for saved in [
            None,
            Some(RegistryValue::Dword(0)),
            Some(RegistryValue::Dword(32)),
            Some(RegistryValue::Sz("".into())),
            Some(RegistryValue::Dword(11)),
            Some(RegistryValue::Dword(31)),
        ] {
            let mut prior = Registry::with_device_defaults();
            prior.configure_persistence(&path).unwrap();
            prior.delete_value(key, "OnLevel");
            prior.delete_value(key, "DimLevel");
            if let Some(value) = saved.clone() {
                prior.set_value(key, "OnLevel", value);
            }
            prior.flush().unwrap();
            let mut loaded = Registry::with_device_defaults();
            loaded.configure_persistence(&path).unwrap();
            let expected = match saved {
                Some(RegistryValue::Dword(level @ 1..=31)) => level,
                _ => 11,
            };
            assert_eq!(
                loaded.value(key, "OnLevel"),
                Some(RegistryValue::Dword(expected))
            );
            assert_eq!(loaded.value(key, "DimLevel"), Some(RegistryValue::Dword(0)));
            assert!(loaded.handles.is_empty());
        }
    }

    #[test]
    fn gizmondo_launch_resets_persisted_brightness_each_time_without_touching_other_values() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let key = r"HKCU\ControlPanel\Backlight";
        let mut previous = Registry::with_device_defaults();
        previous.configure_persistence(&path).unwrap();
        previous.set_value(r"HKCU\Game", "Keep", RegistryValue::Dword(42));
        for level in [31, 1, 21] {
            previous.set_value(key, "OnLevel", RegistryValue::Dword(level));
            previous.set_value(key, "Level", RegistryValue::Dword(level));
            previous.set_value(key, "DimLevel", RegistryValue::Dword(20));
            previous.flush().unwrap();
            let mut launched = Registry::with_device_defaults();
            launched.configure_persistence(&path).unwrap();
            assert_eq!(
                launched.value(key, "OnLevel"),
                Some(RegistryValue::Dword(level))
            );
            launched.reset_gizmondo_backlight().unwrap();
            for name in ["Level", "OnLevel"] {
                assert_eq!(launched.value(key, name), Some(RegistryValue::Dword(11)));
            }
            assert_eq!(
                launched.value(key, "DimLevel"),
                Some(RegistryValue::Dword(0))
            );
            assert_eq!(
                launched.value(r"HKCU\Game", "Keep"),
                Some(RegistryValue::Dword(42))
            );
            let mut reloaded = Registry::with_device_defaults();
            reloaded.configure_persistence(&path).unwrap();
            assert_eq!(
                reloaded.value(key, "OnLevel"),
                Some(RegistryValue::Dword(11))
            );
            previous = launched;
        }
    }

    #[test]
    fn persistence_round_trip_shared_child_and_deletion() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let ram = crate::memory_division::MemoryDivision::default();
        let mut parent = Registry::new();
        assert!(parent.attach_ram(Some(&ram)));
        parent.configure_persistence(&path).unwrap();
        assert!(parent.set_value("HKCU\\Save", "text", RegistryValue::Sz("été".into())));
        assert!(parent.set_value("HKCU\\Save", "number", RegistryValue::Dword(123)));
        let handle = parent.open("HKCU\\Save").unwrap();
        let mut child = Registry::new();
        assert!(child.attach_ram(Some(&ram)));
        child.configure_persistence(&path).unwrap();
        assert!(child.set_value("HKCU\\Save", "blob", RegistryValue::Binary(vec![0, 255, 8])));
        child.flush().unwrap();
        let mut loaded = Registry::new();
        loaded.configure_persistence(&path).unwrap();
        assert_eq!(
            loaded.value("HKCU\\Save", "text"),
            Some(RegistryValue::Sz("été".into()))
        );
        assert_eq!(
            loaded.value("HKCU\\Save", "number"),
            Some(RegistryValue::Dword(123))
        );
        assert_eq!(
            loaded.value("HKCU\\Save", "blob"),
            Some(RegistryValue::Binary(vec![0, 255, 8]))
        );
        assert!(loaded.path_for(handle).is_none());
        assert!(loaded.delete_value("HKCU\\Save", "blob"));
        loaded.flush().unwrap();
        let mut reloaded = Registry::new();
        reloaded.configure_persistence(&path).unwrap();
        assert_eq!(reloaded.value("HKCU\\Save", "blob"), None);
    }

    #[test]
    fn corrupt_persistence_is_rejected_without_changing_live_values_or_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        std::fs::write(&path, b"broken").unwrap();
        let mut reg = Registry::new();
        reg.set_value("HKCU\\Live", "value", RegistryValue::Dword(42));
        assert!(reg.configure_persistence(&path).is_err());
        assert_eq!(
            reg.value("HKCU\\Live", "value"),
            Some(RegistryValue::Dword(42))
        );
        reg.flush().unwrap();
        assert_eq!(std::fs::read(&path).unwrap(), b"broken");
    }

    #[test]
    fn canonicalises_paths_and_roots() {
        assert_eq!(
            canonical_key(r"HKEY_LOCAL_MACHINE\SOFTWARE\Apps\"),
            r"HKLM\SOFTWARE\Apps"
        );
        assert_eq!(
            canonical_key(r"\ControlPanel\Owner\"),
            r"ControlPanel\Owner"
        );
    }

    #[test]
    fn stores_and_reads_values_case_insensitively() {
        let mut reg = Registry::new();
        reg.set_value(
            r"HKLM\SOFTWARE\Apps\Astraware Bejeweled",
            "SaveDir",
            RegistryValue::Sz(r"\My Documents\My Saved Games\Bejeweled".to_string()),
        );
        assert_eq!(
            reg.value(r"hklm\software\apps\astraware bejeweled", "savedir"),
            Some(RegistryValue::Sz(
                r"\My Documents\My Saved Games\Bejeweled".to_string()
            ))
        );
    }

    #[test]
    fn nested_creation_and_seeded_values_materialise_all_parents() {
        for seed_value in [false, true] {
            let mut reg = Registry::new();
            let leaf = r"HKLM\Software\Vendor\Product\Packs\Default";
            if seed_value {
                assert!(reg.set_value(leaf, "First", RegistryValue::Dword(2)));
            } else {
                assert!(reg.create_key(leaf));
            }
            for parent in [
                r"HKLM\Software\Vendor",
                r"HKLM\Software\Vendor\Product",
                r"HKLM\Software\Vendor\Product\Packs",
            ] {
                assert!(reg.open(parent).is_some(), "missing parent {parent}");
            }
            assert_eq!(
                reg.subkeys(r"HKLM\Software\Vendor\Product\Packs"),
                vec!["Default"]
            );
        }
    }

    #[test]
    fn open_only_succeeds_for_existing_keys() {
        let mut reg = Registry::new();
        assert!(reg.open(r"HKLM\SOFTWARE\Nope").is_none());
        reg.create_key(r"HKLM\SOFTWARE\Yes");
        let handle = reg.open(r"HKLM\SOFTWARE\Yes").expect("key exists");
        assert_eq!(reg.path_for(handle).as_deref(), Some(r"hklm\software\yes"));
        // A handle can be used as the root of a relative open.
        reg.create_key(r"HKLM\SOFTWARE\Yes\Child");
        assert_eq!(
            reg.resolve(handle, "Child").as_deref(),
            Some(r"hklm\software\yes\Child")
        );
        reg.close(handle);
        assert!(reg.path_for(handle).is_none());
    }

    #[test]
    fn dword_and_string_encodings_match_win32() {
        assert_eq!(RegistryValue::Dword(1739).type_code(), 4);
        assert_eq!(RegistryValue::Dword(1739).to_bytes(), 1739u32.to_le_bytes());
        let sz = RegistryValue::Sz("AB".to_string());
        assert_eq!(sz.type_code(), 1);
        assert_eq!(sz.to_bytes(), vec![b'A', 0, b'B', 0, 0, 0]);
    }
    #[test]
    fn delete_leaf_key_rejects_open_handles_and_children() {
        let mut reg = Registry::new();
        let key = r"HKCU\Software\Example";
        reg.set_value(key, "Name", RegistryValue::Dword(42));
        let handle = reg.open(key).unwrap();
        assert_eq!(reg.delete_key(0x80000001, r"Software\Example"), Err(5));
        reg.close(handle);
        reg.set_value(r"HKCU\Software\Example\Child", "", RegistryValue::Dword(1));
        assert_eq!(reg.delete_key(0x80000001, r"Software\Example"), Err(5));
        assert_eq!(
            reg.delete_key(0x80000001, r"Software\Example\Child"),
            Ok(())
        );
        assert_eq!(reg.delete_key(0x80000001, r"software\EXAMPLE"), Ok(()));
        assert!(!reg.contains_key(key));
        assert_eq!(reg.delete_key(0x80000001, r"Software\Example"), Err(2));
        assert_eq!(reg.delete_key(0, "Example"), Err(6));
        assert_eq!(reg.delete_key(0x80000001, ""), Err(87));
    }

    #[test]
    fn game_overrides_read_and_enumerate_without_persisting_or_leaking() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("registry.json");
        let key = r"HKCU\ControlPanel\Owner";
        let mut game = Registry::with_device_defaults();
        game.configure_persistence(&path).unwrap();
        let baseline = game.value(key, "Owner").unwrap();
        game.set_volatile_value(key, "Owner", RegistryValue::Sz("Game A".into()));
        assert_eq!(
            game.value(key, "OWNER"),
            Some(RegistryValue::Sz("Game A".into()))
        );
        assert!(game
            .values(key)
            .iter()
            .any(|(_, v)| v == &RegistryValue::Sz("Game A".into())));
        let mut child = Registry::new();
        child.store = game.store.clone();
        child.volatile_values = game.volatile_values.clone();
        assert!(game.set_value(
            key,
            "Owner",
            RegistryValue::Sz("Temporary guest edit".into())
        ));
        assert_eq!(child.value(key, "Owner"), game.value(key, "Owner"));
        let isolated = game.isolated_copy();
        assert!(game.delete_value(key, "Owner"));
        assert!(game.value(key, "Owner").is_none());
        assert!(isolated.value(key, "Owner").is_some());
        game.flush().unwrap();
        let mut next = Registry::with_device_defaults();
        next.configure_persistence(&path).unwrap();
        assert_eq!(next.value(key, "Owner"), Some(baseline));
    }
}
