//! Top-level emulator object that the frontends drive.
//!
//! Usage:
//!
//! ```no_run
//! use pocket_core::Emulator;
//! let mut emu = Emulator::with_stub_cpu();
//! emu.load_pe("/path/to/JumpyBallPPC.exe").unwrap();
//! emu.run().unwrap();
//! ```
//!
//! When compiled with `--features unicorn`, [`Emulator::with_unicorn_cpu`]
//! provides a fully working ARM backend.

mod cab_setup;
mod colors_wallet;

use std::path::Path;

use anyhow::{Context, Result};

use pocket_cpu::{stub::StubCpu, Cpu};
use pocket_kernel::{run_main_loop, run_main_loop_with_hook, FrameHook, Process};
use pocket_winceapi::WinCeDispatcher;

pub use pocket_cab as cab;
pub use pocket_cpu as cpu;
pub use pocket_kernel as kernel;
pub use pocket_pe as pe;
pub use pocket_winceapi as winceapi;

pub struct Emulator {
    cpu: Box<dyn Cpu>,
    process: Option<Process>,
    dispatcher: WinCeDispatcher,
    /// Screen geometry requested by the frontend, remembered so
    /// [`Emulator::set_screen_size`] works whether it is called before
    /// or after [`Emulator::load_pe`]. See that method for why.
    requested_screen: Option<(u32, u32)>,
    requested_frame_rate_limit: Option<u32>,
    pub instruction_budget_per_slice: u64,
    pub max_slices: u64,
}

impl Emulator {
    pub fn with_stub_cpu() -> Self {
        Self {
            cpu: Box::new(StubCpu::new()),
            process: None,
            dispatcher: WinCeDispatcher::new(),
            requested_screen: None,
            requested_frame_rate_limit: None,
            instruction_budget_per_slice: 1_000_000,
            max_slices: 1024,
        }
    }

    /// Build with the unicorn-engine backed CPU. Requires the
    /// `unicorn` Cargo feature.
    #[cfg(feature = "unicorn")]
    pub fn with_unicorn_cpu() -> Result<Self> {
        Self::with_unicorn_cpu_for_arch(pocket_cpu::Arch::Arm)
    }

    #[cfg(feature = "unicorn")]
    pub fn with_unicorn_cpu_for_arch(arch: pocket_cpu::Arch) -> Result<Self> {
        let cpu = pocket_cpu::unicorn::UnicornCpu::new_for_arch(arch)
            .context("creating unicorn-engine CPU instance")?;
        Ok(Self {
            cpu: Box::new(cpu),
            process: None,
            dispatcher: WinCeDispatcher::new(),
            requested_screen: None,
            requested_frame_rate_limit: None,
            instruction_budget_per_slice: 1_000_000,
            max_slices: 1024,
        })
    }

    /// Select the Pocket PC physical action key after loading a process.
    /// The default and Gizmondo profile retain their legacy GAPI key mapping.
    pub fn set_pocket_pc_input(&mut self, enabled: bool) {
        if let Some(process) = self.process.as_mut() {
            process.state.gapi_action_key = if enabled {
                pocket_kernel::gapi::VK_RETURN
            } else {
                pocket_kernel::gapi::VK_A
            };
        }
    }

    /// Apply the Gizmondo audio compatibility profile after loading a process.
    /// The 32-handle budget restores finite-capacity enumeration for console
    /// software. It is a compatibility policy, not a ROM-proven hardware limit.
    /// Pocket PC retains dynamically allocated software streams without a cap.
    pub fn set_gizmondo_audio_compatibility(&mut self, enabled: bool) {
        if let Some(process) = self.process.as_mut() {
            process.state.wave_out.open_handle_limit = enabled.then_some(32);
        }
    }

    /// Add an optional presentation ceiling without changing the guest clock.
    /// May be called before or after loading. None retains existing display sync.
    pub fn set_frame_rate_limit(&mut self, fps: Option<u32>) {
        self.requested_frame_rate_limit =
            fps.filter(|fps| matches!(fps, 10 | 15 | 20 | 30 | 45 | 60));
        if let Some(process) = self.process.as_mut() {
            let clock = &mut process.state.framebuffer.directdraw;
            clock.frame_rate_limit = self.requested_frame_rate_limit;
            clock.pending.clear();
        }
    }

    /// Experimental host GPU rasterizer, configured on the running thread.
    pub fn set_gpu_renderer(&mut self, enabled: bool) {
        pocket_winceapi::gles::set_gpu_renderer(enabled);
    }

    pub fn set_anisotropic_filtering(&mut self, level: u8) {
        pocket_winceapi::gles::set_anisotropic_filtering(level);
    }

    /// Halt the emulator the first time an unimplemented API is hit.
    /// Useful for the tracing CLI mode.
    pub fn set_halt_on_unimplemented(&mut self, halt: bool) {
        self.dispatcher.halt_on_unimplemented = halt;
    }

    /// Forward every dispatched API call as JSON-lines to `sink`.
    pub fn set_trace_sink(&mut self, sink: Box<dyn std::io::Write + Send>) {
        self.dispatcher.set_trace_sink(sink);
    }

    /// Report only missing API handlers, without enabling the all-call trace.
    pub fn set_unimplemented_api_sink(
        &mut self,
        sink: Box<dyn pocket_winceapi::UnimplementedApiSink>,
    ) {
        self.dispatcher.set_unimplemented_api_sink(sink);
    }

    /// Load and map a PE file into the emulator. Existing process
    /// state is replaced.
    pub fn load_pe(&mut self, path: impl AsRef<Path>) -> Result<&Process> {
        let path = path.as_ref();
        let raw = std::fs::read(path).context("reading PE")?;
        let mut image = pe::load_bytes(&raw).context("loading PE")?;
        image.source_path = path.display().to_string();
        colors_wallet::apply(&raw, &mut image).context("Colors wallet compatibility")?;
        pocket_winceapi::reset_media_backends();
        let arch = self.cpu.arch();
        let gles_tables = pocket_winceapi::gles_exports::local_tables(path, &image)
            .map_err(anyhow::Error::msg)?;
        let mut process = Process::map_into(
            image,
            self.cpu.as_mut(),
            &|dll, ord| pocket_winceapi::gles_exports::resolve(&gles_tables, dll, ord, arch),
            &self.dispatcher,
        )
        .context("mapping image into CPU")?;
        process.state.gles_local_ordinals = gles_tables;
        self.process = Some(process);
        // A frontend that sized the screen before loading gets its
        // request honoured here rather than silently dropped.
        if let Some((w, h)) = self.requested_screen {
            self.apply_screen_size(w, h);
        }
        self.set_frame_rate_limit(self.requested_frame_rate_limit);
        Ok(self.process.as_ref().unwrap())
    }

    /// Run until the emulator halts. Returns the number of slices
    /// consumed.
    pub fn run(&mut self) -> Result<()> {
        let process = self
            .process
            .as_mut()
            .context("no PE loaded — call load_pe() first")?;
        run_main_loop(
            self.cpu.as_mut(),
            process,
            &mut self.dispatcher,
            self.instruction_budget_per_slice,
            self.max_slices,
        )
        .context("main emulator loop")
    }

    /// Like [`Self::run`], but routes the framebuffer through
    /// `frame_hook` once per dispatch slice.
    pub fn run_with_hook(&mut self, frame_hook: &mut dyn FrameHook) -> Result<()> {
        let process = self
            .process
            .as_mut()
            .context("no PE loaded — call load_pe() first")?;
        run_main_loop_with_hook(
            self.cpu.as_mut(),
            process,
            &mut self.dispatcher,
            self.instruction_budget_per_slice,
            self.max_slices,
            Some(frame_hook),
        )
        .context("main emulator loop")
    }

    /// Configure CE WinMain's UTF-16 argument and GetCommandLine before execution.
    pub fn set_startup_command_line(&mut self, command: &str) -> Result<()> {
        let process = self.process.as_mut().context("no PE loaded")?;
        let bytes: Vec<u8> = command
            .encode_utf16()
            .chain(std::iter::once(0))
            .flat_map(u16::to_le_bytes)
            .collect();
        let old = self.cpu.read_reg(pocket_cpu::regs::ArmReg::R2)?;
        let address = process
            .state
            .heap
            .alloc(bytes.len() as u32)
            .context("command line out of memory")?;
        if let Err(error) = self
            .cpu
            .write_mem(address, &bytes)
            .and_then(|_| self.cpu.write_reg(pocket_cpu::regs::ArmReg::R2, address))
        {
            process.state.heap.free(address);
            return Err(error.into());
        }
        process.state.heap.free(old);
        process.state.command_line = Some(command.to_string());
        process.state.command_line_cache = Some(address);
        Ok(())
    }

    pub fn process(&self) -> Option<&Process> {
        self.process.as_ref()
    }

    pub fn process_mut(&mut self) -> Option<&mut Process> {
        self.process.as_mut()
    }
    /// Start the host audio backend after the guest process has been loaded.
    pub fn start_audio(&mut self) {
        if let Some(process) = self.process.as_mut() {
            process.state.audio.start();
        }
    }

    /// Stop the host audio backend and flush pending samples.
    pub fn stop_audio(&mut self) {
        if let Some(process) = self.process.as_mut() {
            process.state.audio.stop();
        }
    }

    /// Select the global PocketPC OEM processor identity for this process.
    pub fn set_pocketpc_processor(&mut self, id: &str) -> Result<()> {
        let profile = pocket_kernel::processor_info::PocketPcProcessor::from_id(id)
            .ok_or_else(|| anyhow::anyhow!("Unknown PocketPC processor profile: {id}"))?;
        let process = self
            .process
            .as_mut()
            .ok_or_else(|| anyhow::anyhow!("No loaded process"))?;
        process.state.pocketpc_processor = Some(profile);
        Ok(())
    }

    /// Optional PocketPC shared runtime search path. Game-local paths stay first.
    pub fn configure_pocketpc_dependencies(
        &mut self,
        root: &Path,
        notice: impl FnMut(String) + Send + 'static,
    ) {
        let folder = root.join("runtimes").join("pocketpc");
        if let Err(error) = std::fs::create_dir_all(&folder) {
            log::warn!(
                "Cannot create shared runtime directory {}: {error}",
                folder.display()
            );
        }
        if let Some(process) = self.process.as_mut() {
            process.state.module_search_dirs.push(folder);
        }
        self.dispatcher.set_dependency_notice(Box::new(notice));
    }

    pub fn dispatcher(&self) -> &WinCeDispatcher {
        &self.dispatcher
    }

    /// Write raw bytes into emulated guest memory. Useful for patching
    /// the loaded image (e.g. NOP'ing out a hostile static-init call)
    /// before [`Self::run`] is invoked.
    pub fn write_guest_memory(&mut self, addr: u32, bytes: &[u8]) -> Result<()> {
        self.cpu
            .write_mem(addr, bytes)
            .map_err(|e| anyhow::anyhow!(e))
    }

    /// Read guest memory for an explicitly requested diagnostic snapshot.
    pub fn read_guest_memory(&mut self, addr: u32, size: u32) -> Result<Vec<u8>> {
        self.cpu
            .read_mem(addr, size)
            .map_err(|e| anyhow::anyhow!(e))
    }

    /// Install an instruction-level code hook at the given guest VA.
    /// Used by `--watch` for diagnostic breakpoints. When the CPU
    /// reaches the address, the kernel run loop will dump registers
    /// and halt cleanly.
    pub fn add_code_hook(&mut self, va: u32) -> Result<()> {
        self.cpu.add_code_hook(va).map_err(|e| anyhow::anyhow!(e))
    }

    pub fn add_register_trace(&mut self, va: u32, label: &'static str) -> Result<()> {
        self.cpu
            .add_register_trace(va, label)
            .map_err(|e| anyhow::anyhow!(e))
    }

    /// Provide the ordinary writable PocketPC system namespace between launches.
    /// Existing per-game and card mounts remain more specific than this root.
    pub fn configure_pocketpc_storage(&mut self, library_root: &Path) -> Result<()> {
        let process = self
            .process
            .as_mut()
            .context("PocketPC storage requires a loaded process")?;
        // Never replace the quota-managed RAM namespace of another profile with
        // an uncharged host mount. Current PocketPC launchers use the host model.
        anyhow::ensure!(
            process.state.memory_division.is_none(),
            "PocketPC host storage cannot replace a RAM-backed device profile"
        );
        pocketpc_storage::mount(&mut process.state.vfs, library_root)
            .context("initializing PocketPC object store")
    }

    /// Mount a host directory at a guest WinCE path. Useful for
    /// satisfying `CreateFileW` requests once the PE is loaded.
    pub fn mount_dir(&mut self, guest_prefix: &str, host_dir: impl Into<std::path::PathBuf>) {
        if let Some(p) = self.process.as_mut() {
            p.state.vfs.mount(guest_prefix, host_dir);
        } else {
            log::warn!("mount_dir called before load_pe; ignored");
        }
    }

    pub fn mount_read_only_dir(
        &mut self,
        guest_prefix: &str,
        host_dir: impl Into<std::path::PathBuf>,
    ) {
        if let Some(p) = self.process.as_mut() {
            p.state.vfs.mount_read_only(guest_prefix, host_dir);
        } else {
            log::warn!("mount_read_only_dir called before load_pe; ignored");
        }
    }

    pub fn mount_save_dir(&mut self, guest_prefix: &str, host_dir: impl Into<std::path::PathBuf>) {
        if let Some(p) = self.process.as_mut() {
            p.state.vfs.mount_save_dir(guest_prefix, host_dir);
        } else {
            log::warn!("mount_save_dir called before load_pe; ignored");
        }
    }

    /// Set the guest path `GetModuleFileNameW` reports for the running
    /// executable.
    ///
    /// Pocket PC titles routinely locate their assets *relative to
    /// their own module path*: they call `GetModuleFileNameW`, subtract
    /// the length of a hard-coded `L"<Game>.exe"` literal, and append
    /// the asset name. Reporting a generic placeholder therefore breaks
    /// them, so frontends pass the path the installer would have used
    /// on a real device.
    pub fn set_module_path(&mut self, path: impl Into<String>) {
        let path = path.into();
        if let Some(p) = self.process.as_mut() {
            p.state.module_path = path;
        } else {
            log::warn!("set_module_path called before load_pe; ignored");
        }
    }

    /// Override how many synthetic `WM_PAINT` messages the dispatcher
    /// will hand out before posting `WM_QUIT`. Pass `0` for unlimited
    /// (the message loop will keep running until another path halts
    /// the emulator).
    pub fn set_synthetic_message_budget(&mut self, budget: u64) {
        if let Some(p) = self.process.as_mut() {
            p.state.synthetic_message_budget = budget;
        }
    }

    /// Pre-seed a registry value, as a cabinet's `_setup.xml`
    /// `<characteristic type="Registry">` block would have on install.
    ///
    /// Pocket PC games read their save directory (and sometimes their
    /// licence record) back out of the registry the installer wrote;
    /// Astraware's Bejeweled calls `ExitProcess(0x42)` when
    /// `HKLM\SOFTWARE\Apps\Astraware Bejeweled\SaveDir` is missing.
    pub fn set_registry_value(
        &mut self,
        key: &str,
        name: &str,
        value: pocket_kernel::registry::RegistryValue,
    ) {
        if let Some(p) = self.process.as_mut() {
            p.state.registry.set_value(key, name, value);
        }
    }
    /// Apply one game's PocketPC identity without changing the persisted device.
    pub fn set_pocketpc_identity(
        &mut self,
        owner: &str,
        name: &str,
        platform_hex: &str,
    ) -> Result<()> {
        use pocket_kernel::{
            device_identity::{DeviceIdentity, REGISTRY_KEY, REGISTRY_VALUE},
            registry::RegistryValue,
        };
        anyhow::ensure!(
            !owner.contains('\0') && owner.encode_utf16().count() <= 255,
            "Owner name must contain at most 255 characters and no NUL"
        );
        anyhow::ensure!(
            !name.contains('\0') && name.is_ascii() && name.len() <= 4096,
            "PocketPC device name must use ASCII characters without NUL (maximum 4096 bytes)"
        );
        let process = self.process.as_mut().context("no PE loaded")?;
        let mut id = DeviceIdentity::load_or_create(&mut process.state.registry)
            .map_err(anyhow::Error::msg)?;
        if !name.is_empty() {
            id.preset = name.as_bytes().to_vec();
        }
        if !platform_hex.is_empty() {
            id = DeviceIdentity::from_hex(&DeviceIdentity::hex(&id.preset), platform_hex)
                .map_err(anyhow::Error::msg)?;
        }
        let encoded = id.encode().map_err(anyhow::Error::msg)?;
        if !owner.is_empty() {
            process.state.registry.set_volatile_value(
                r"HKCU\ControlPanel\Owner",
                "Owner",
                RegistryValue::Sz(owner.into()),
            );
        }
        if !name.is_empty() {
            process.state.registry.set_volatile_value(
                r"HKLM\Ident",
                "Name",
                RegistryValue::Sz(name.into()),
            );
        }
        if !name.is_empty() || !platform_hex.is_empty() {
            process.state.registry.set_volatile_value(
                REGISTRY_KEY,
                REGISTRY_VALUE,
                RegistryValue::Binary(encoded),
            );
        }
        Ok(())
    }
    /// Set the directory relative guest paths resolve against.
    ///
    /// Windows CE has no per-process working directory, but games ship
    /// relative paths anyway (`FindFirstFile(".\\*.pdb")` in Astraware's
    /// Bejeweled). Anchoring them at the executable's install directory
    /// is what those titles expect, because that is where the shell
    /// launched them from.
    pub fn set_default_dir(&mut self, guest_dir: &str) {
        if let Some(p) = self.process.as_mut() {
            p.state.vfs.set_default_dir(guest_dir);
        }
    }

    /// Tee every PCM sample the guest submits into a 16-bit WAV file.
    ///
    /// Headless machines (CI, containers) have no audio device, so the
    /// only way to check that a game really produces sound is to
    /// record what it sent. Must be called after `load_pe`.
    pub fn capture_audio_to(&mut self, path: &std::path::Path) -> std::io::Result<()> {
        match self.process.as_mut() {
            Some(p) => p.state.audio.capture_to(path),
            None => {
                log::warn!("capture_audio_to called before load_pe; ignored");
                Ok(())
            }
        }
    }

    /// A pull handle for hosts that play the guest's PCM themselves.
    ///
    /// The Android frontend uses this: it has no cpal backend, so the
    /// JNI layer drains the tap on a helper thread and writes into a
    /// Java `AudioTrack`. Returns `None` before `load_pe`.
    pub fn audio_tap(&self) -> Option<pocket_kernel::AudioTap> {
        self.process.as_ref().map(|p| p.state.audio.tap())
    }

    /// Resize the emulated display. Call it any time before
    /// [`Self::run`] — either side of [`Self::load_pe`] works, because
    /// a request made before the process exists is remembered and
    /// applied by `load_pe`. It must precede `run`, since the guest
    /// reads the geometry once during start-up (`GetSystemMetrics`,
    /// `GetDeviceCaps`, `GXGetDisplayProperties`) and sizes its back
    /// buffer from it.
    ///
    /// The ordering used to matter and silently didn't hold: the
    /// desktop launcher sized the screen before loading, so every game
    /// ran at the default no matter which resolution the user picked in
    /// the GUI. Deferring instead of dropping the request keeps that
    /// class of bug from coming back through a new frontend.
    ///
    /// The default is the Pocket PC 240×320 portrait LCD. Windows
    /// Mobile Smartphone titles — e.g. the Motorola Q9 build of
    /// Asphalt 2 — expect a 320×240 landscape screen and will
    /// otherwise blit a surface that our framebuffer silently clips.
    pub fn set_screen_size(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            log::warn!("set_screen_size({width}x{height}) ignored: zero dimension");
            return;
        }
        self.requested_screen = Some((width, height));
        if self.process.is_some() {
            self.apply_screen_size(width, height);
        }
    }

    /// Configure the CE RAM partition after loading the process. A missing
    /// profile stays unsupported rather than borrowing another device's RAM.
    pub fn set_memory_division(
        &mut self,
        division: Option<pocket_kernel::memory_division::MemoryDivision>,
    ) -> bool {
        self.process
            .as_mut()
            .is_some_and(|process| process.state.configure_memory_division(division))
    }

    /// Screen geometry the guest will see, once [`Self::load_pe`] has
    /// run. Reflects the live framebuffer, so it also covers a game
    /// that resized the display itself.
    pub fn screen_size(&self) -> Option<(u32, u32)> {
        let fb = &self.process.as_ref()?.state.framebuffer;
        Some((fb.width, fb.height))
    }

    /// Resize the live framebuffer. Only valid with a process loaded.
    fn apply_screen_size(&mut self, width: u32, height: u32) {
        let Some(p) = self.process.as_mut() else {
            return;
        };
        p.state.framebuffer = pocket_kernel::Framebuffer::new(width, height);
        p.state.framebuffer.directdraw.frame_rate_limit = self.requested_frame_rate_limit;
        // The GAPI mapping is sized from the framebuffer, so drop it;
        // the next GXOpenDisplay/GXBeginDraw re-maps at the new size.
        p.state.fb_mapped = false;
        p.state.guest_fb_pitch = 0;
        p.state.gx_readback_scratch.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stub_emulator_constructs() {
        let _ = Emulator::with_stub_cpu();
    }

    #[test]
    fn frame_rate_limit_can_be_configured_before_loading() {
        let mut emu = Emulator::with_stub_cpu();
        assert_eq!(emu.requested_frame_rate_limit, None);
        emu.set_frame_rate_limit(Some(20));
        emu.set_screen_size(640, 480);
        assert_eq!(emu.requested_frame_rate_limit, Some(20));
        emu.set_frame_rate_limit(Some(0));
        assert_eq!(emu.requested_frame_rate_limit, None);
        emu.set_frame_rate_limit(Some(60));
        emu.set_frame_rate_limit(None);
        assert_eq!(emu.requested_frame_rate_limit, None);
    }

    #[test]
    fn a_screen_size_set_before_load_is_remembered() {
        // The desktop launcher sizes the screen before it loads the PE.
        // That used to be silently dropped, so every game ran at the
        // 240x320 default however the user configured it. The request
        // has to survive until there is a process to apply it to.
        let mut emu = Emulator::with_stub_cpu();
        assert_eq!(emu.screen_size(), None, "no process yet");
        emu.set_screen_size(480, 320);
        assert_eq!(
            emu.requested_screen,
            Some((480, 320)),
            "request must be kept for load_pe to apply"
        );
    }

    #[test]
    fn a_zero_dimension_screen_size_is_refused() {
        // Never leave a zero-sized framebuffer behind: a later
        // load_pe must not apply it either.
        let mut emu = Emulator::with_stub_cpu();
        emu.set_screen_size(480, 0);
        assert_eq!(emu.requested_screen, None);
        emu.set_screen_size(0, 320);
        assert_eq!(emu.requested_screen, None);
    }
}

impl Drop for Emulator {
    fn drop(&mut self) {
        pocket_winceapi::reset_media_backends();
    }
}

/// Temporarily detach host GLES/media state without unloading the CPU or
/// process. The caller must drop the child emulator before this guard.
pub fn suspend_host_session() -> pocket_winceapi::SuspendedSession {
    pocket_winceapi::suspend_session()
}

pub mod dependencies;
mod pocketpc_storage;
