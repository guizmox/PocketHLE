package com.pockethle.app

/**
 * Thin Kotlin facade around the Rust JNI library `libpockethle_jni.so`.
 *
 * Most native methods take the absolute path of the library root as
 * their first argument and return a JSON-encoded string. JSON is
 * used as the lingua franca to keep the FFI surface minimal — no
 * shared data classes between Rust and Kotlin.
 *
 * The session-based methods (`nativeStartGame`, `nativePollFrame`,
 * `nativeSendInput`, `nativeRequestStop`, `nativeFinishGame`) are
 * the ones [GameActivity] uses to drive the real-time emulator.
 * They do *not* round-trip JSON; they exchange a `long` opaque
 * handle and raw `ByteArray` blobs to avoid the overhead of
 * encoding the framebuffer on every poll.
 */
object NativeBridge {
    @JvmStatic fun vibOpen(): Int = VibrationHost.open()
    @JvmStatic fun vibApply(id: Int, timings: LongArray): Int = VibrationHost.apply(id, timings)
    @JvmStatic fun vibClose(id: Int) = VibrationHost.close(id)
    @JvmStatic fun httpSessionOpen(spec: String): Int = InternetHost.openSession(spec)
    @JvmStatic fun httpSessionClose(id: Int) = InternetHost.closeSession(id)
    @JvmStatic fun httpStart(id: Int, spec: String, body: ByteArray): Int = InternetHost.start(id, spec, body)
    @JvmStatic fun httpHead(id: Int): String = InternetHost.head(id)
    @JvmStatic fun httpAvailable(id: Int): Long = InternetHost.available(id)
    @JvmStatic fun httpRead(id: Int, size: Int): ByteArray = InternetHost.read(id, size)
    @JvmStatic fun httpClose(id: Int) = InternetHost.close(id)
    @JvmStatic fun batteryStatus(): Int = BatteryHost.read()
    @JvmStatic fun deviceStatus(): Int = DeviceStatusHost.read()
    @JvmStatic fun gpsOpen(): Int = GpsHost.open()
    @JvmStatic fun gpsRead(id: Int): ByteArray = GpsHost.read(id)
    @JvmStatic fun gpsClose(id: Int) = GpsHost.close(id)
    @JvmStatic fun camOpen(): Int = CameraHost.open()
    @JvmStatic fun camRead(id: Int): ByteArray = CameraHost.read(id)
    @JvmStatic fun camClose(id: Int) = CameraHost.close(id)
    @JvmStatic fun btSocketCall(request: String): String = RfcommHost.call(request)
    @JvmStatic fun btSocketStatus(id: Int): Int = RfcommHost.status(id)
    @JvmStatic fun btSocketRead(id: Int, count: Int, peek: Boolean): ByteArray = RfcommHost.read(id, count, peek)
    @JvmStatic fun btSocketWrite(id: Int, bytes: ByteArray): Int = RfcommHost.write(id, bytes)
    @JvmStatic fun btReady(): Int = BluetoothHost.ready()
    @JvmStatic fun btHostname(): String = BluetoothHost.hostname()
    @JvmStatic fun btScan(): String = BluetoothHost.scan()
    @JvmStatic fun btOpen(server: Boolean, address: Long, uuid: String): Int = BluetoothHost.open(server, address, uuid)
    @JvmStatic fun btStatus(id: Int): Int = BluetoothHost.status(id)
    @JvmStatic fun btRead(id: Int, count: Int): ByteArray = BluetoothHost.read(id, count)
    @JvmStatic fun btWrite(id: Int, bytes: ByteArray): Int = BluetoothHost.write(id, bytes)
    @JvmStatic fun btClose(id: Int) = BluetoothHost.close(id)
    init {
        System.loadLibrary("pockethle_jni")
    }

    @JvmStatic external fun renameGame(libraryRoot: String, id: String, name: String): String
    @JvmStatic external fun isGizmondoGame(libraryRoot: String, id: String): Boolean
    @JvmStatic external fun upscaleXbrz(rgba: ByteArray, width: Int, height: Int): ByteArray?
    @JvmStatic external fun analyzeGame(libraryRoot: String, id: String): String
    /** mode: -1 save, 0 merge without overwrite, 1 merge overwrite, 2 replace. */
    @JvmStatic external fun libraryBackup(libraryRoot: String, archive: String, mode: Int): String
    @JvmStatic external fun banner(): String

    /** Returns a JSON array of [GameEntry]. */
    @JvmStatic external fun listGames(libraryRoot: String): String
    @JvmStatic external fun isColorsGame(libraryRoot: String, id: String): Boolean
    @JvmStatic external fun colorsLanguages(libraryRoot: String, id: String): String
    @JvmStatic external fun unlockColorsTurfWars(libraryRoot: String, id: String): String

    /** Returns the freshly imported game as a JSON [GameEntry]. */
    @JvmStatic external fun prepareImport(libraryRoot: String, source: String): String
    @JvmStatic external fun choosePreparedImportCabinet(libraryRoot: String, token: Long, index: Int): String
    @JvmStatic external fun choosePreparedImportPlatform(libraryRoot: String, token: Long, gameId: String, gizmondo: Boolean): String
    @JvmStatic external fun commitPreparedImport(libraryRoot: String, token: Long, allowUpdates: Boolean): String
    @JvmStatic external fun cancelPreparedImport(libraryRoot: String, token: Long)

    @JvmStatic external fun importCab(libraryRoot: String, cabPath: String): String
    @JvmStatic external fun isDemoCard(libraryRoot: String, id: String): Boolean
    @JvmStatic external fun splitDemoCard(libraryRoot: String, id: String): String
    /** Returns one JSON GameEntry, or an array for an automatic GZGA collection import. */
    @JvmStatic external fun importZip(libraryRoot: String, zipPath: String): String
    /** Imports a RAR archive containing a Pocket PC game. */
    @JvmStatic external fun importRar(libraryRoot: String, rarPath: String): String
    /** Imports a standalone ARM Pocket PC executable. */
    @JvmStatic external fun importExe(libraryRoot: String, exePath: String): String

    /** Returns `{"ok":true}` on success or `{"ok":false,"error":...}`. */
    @JvmStatic external fun removeGame(libraryRoot: String, id: String): String

    /** Returns the launcher config as JSON. */
    @JvmStatic external fun readConfig(libraryRoot: String): String

    /** Persists the launcher config from a JSON blob. */
    @JvmStatic external fun writeConfig(libraryRoot: String, configJson: String): String

    /** Returns the per-game settings as JSON. */
    @JvmStatic external fun readGameSettings(libraryRoot: String, id: String): String

    /** Persists the per-game settings from a JSON blob. */
    @JvmStatic external fun writeGameSettings(
        libraryRoot: String,
        id: String,
        settingsJson: String,
    ): String

    /**
     * Legacy single-shot run. Blocks the caller until the emulator
     * has finished, then returns a JSON object of the form
     * `{"ok":true,"summary":"...","frame":{"width":W,"height":H,"rgba_b64":"..."}}`
     * or `{"ok":false,"error":"..."}`. Kept for compatibility with
     * other callers but no longer used by [GameActivity] because
     * the real Unicorn backend takes long enough that the call
     * looks like a hang to the user.
     */
    @JvmStatic external fun runGame(libraryRoot: String, id: String): String

    // -------------------------------------------------------------------
    // Session-based emulator API. See `pocket-android-jni::runner`.
    // -------------------------------------------------------------------

    /**
     * Spawn a worker thread that drives the emulator for [id].
     * Returns an opaque handle (>0 on success, 0 on failure). Pass
     * the same handle into every other `native…` call below until
     * [nativeFinishGame] is called, after which the handle is
     * invalid and **must not** be passed back in.
     */
    @JvmStatic external fun nativeStartGame(libraryRoot: String, id: String): Long

    /** Completed display presentations per second, or -1 for changed-image (IPS) fallback. */
    @JvmStatic external fun nativePresentationFps(handle: Long): Float

    /**
     * Poll for the latest framebuffer the worker has produced.
     * Returns `null` if no new frame is available, or a flat byte
     * array `[w0 w1 w2 w3 h0 h1 h2 h3 r0 g0 b0 a0 r1 g1 b1 a1 …]`
     * (width and height as little-endian `u32`).
     */
    @JvmStatic external fun nativePollFrame(handle: Long): ByteArray?

    /** Guest audio format packed as `(sampleRate << 16) | channels`. */
    @JvmStatic external fun nativeAudioFormat(handle: Long): Long

    /** Pull up to [maxSamples] interleaved signed 16-bit PCM samples. */
    @JvmStatic external fun nativePollAudio(handle: Long, maxSamples: Int): ShortArray?

    /** Pending missing-dependency diagnostic, once per DLL and process. */
    @JvmStatic external fun nativePollDependencyNotice(handle: Long): String?
    @JvmStatic external fun nativePollGpsNotice(handle: Long): String?
    /** `1` while the worker is running, `0` after it exits. */
    @JvmStatic external fun nativeIsRunning(handle: Long): Int

    /**
     * Forward a single input event into the running emulator.
     *
     * @param kind one of [INPUT_KEY_DOWN], [INPUT_KEY_UP],
     *   [INPUT_POINTER_DOWN], [INPUT_POINTER_UP].
     * @param a virtual-key code (Win32 VK_*) for KEY_*; X
     *   coordinate (in 240×320 game space) for POINTER_*.
     * @param b ignored for KEY_*; Y coordinate for POINTER_*.
     */
    const val INPUT_KEYBOARD_ROTATION = 5

    @JvmStatic external fun nativeSendInput(
        handle: Long,
        kind: Int,
        a: Int,
        b: Int,
    ): Int

    /** Ask the worker to stop at the next slice boundary. */
    @JvmStatic external fun nativeRequestStop(handle: Long)

    /**
     * Join the worker thread, free the session, and return the
     * textual summary it produced. After this call the handle is
     * invalid and **must not** be passed back in.
     */
    @JvmStatic external fun nativeFinishGame(handle: Long): String

    const val INPUT_TOUCH_STEERING: Int = 7
    const val INPUT_STYLUS_AIM: Int = 6
    const val INPUT_KEY_DOWN: Int = 0
    const val INPUT_KEY_UP: Int = 1
    const val INPUT_POINTER_DOWN: Int = 2
    const val INPUT_POINTER_UP: Int = 3
    const val INPUT_POINTER_MOVE: Int = 4
}
