//! Session-based emulator runner exposed to the Android JNI layer.
//!
//! The desktop GUI ([`pocket_desktop::runner`]) drives the emulator
//! on a background thread and streams a [`FrameSnapshot`] to the UI
//! every time the guest produces a new framebuffer. The Android
//! frontend used to do something fundamentally different: a single
//! blocking JNI call (`runGame`) that ran the emulator to
//! completion, captured the **final** framebuffer, and only then
//! returned. With the trace-only stub backend that returned in a
//! few milliseconds and the user just saw a static screenshot. With
//! the real Unicorn backend wired up in
//! [PR #11](https://github.com/j92580498-max/PocketHLE/pull/11) the
//! emulator now actually executes ARM code and reaches the menu, so
//! `runGame` would happily churn through 1024 dispatch slices ×
//! 1 000 000 instructions/slice on the phone CPU before returning —
//! visually that looks identical to a hang ("infinite loading
//! spinner") and there is no way for the user to push input or
//! quit. That's the symptom this module fixes.
//!
//! The new flow mirrors the desktop runner, just over JNI:
//!
//! 1. Kotlin calls [`start`] with the library root and game id. We
//!    spawn a worker thread that owns the [`Emulator`] and runs it
//!    with a [`FrameHook`]. The worker shares a [`SessionState`]
//!    with the UI thread:
//!      * a `Mutex<Option<FrameSnapshot>>` slot holding the most
//!        recent framebuffer — the Kotlin polling loop drains it
//!        with [`poll_frame`];
//!      * an [`InputCommand`] channel — Kotlin pushes touches,
//!        D-pad presses and the "stop" signal with [`send_input`] /
//!        [`request_stop`].
//! 2. When Kotlin's [`finish`] runs (Back button or
//!    `onDestroy`), we set `should_stop`, join the worker thread
//!    and return a textual summary that the UI shows in its status
//!    panel.
//!
//! Sessions are owned by Kotlin via a `jlong` handle. The handle is
//! a `Box::into_raw`'d pointer to a [`Session`]; [`finish`]
//! reconstructs the box and drops it. The pointer is opaque to
//! Kotlin and, crucially, the JNI methods bounds-check it against
//! `null` and the dispatch refuses to operate on a freed session
//! (we set the in-flight `running` flag to `false` once the worker
//! exits, which lets the polling loop on the UI thread notice the
//! session ended and stop calling back in).

use pocket_core::kernel::{
    handles::HandleTable, memory_division::MemoryDivision, ProcessHandleContext,
};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender, TryRecvError};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

use anyhow::Context;
use pocket_core::kernel::{FrameAction, FrameHook, InputEvent, KernelState};
use pocket_core::Emulator;
use pocket_library::{is_gizmondo_game, CpuBackendPref, GameEntry, Library};

const FRAME_PUSH_INTERVAL: Duration = Duration::from_millis(16);

fn presentation_phase(last: Option<Instant>, now: Instant) -> Option<Instant> {
    let Some(last) = last else {
        return Some(now);
    };
    let elapsed = now.saturating_duration_since(last);
    if elapsed < FRAME_PUSH_INTERVAL {
        return None;
    }
    // Skip missed slots after a pause; never send a burst of catch-up frames.
    let remainder =
        Duration::from_nanos((elapsed.as_nanos() % FRAME_PUSH_INTERVAL.as_nanos()) as u64);
    Some(now - remainder)
}

/// Snapshot of the guest framebuffer plus the dimensions Kotlin
/// needs to paint it onto a `SurfaceView`.
#[derive(Debug, Clone)]
pub struct FrameSnapshot {
    pub presentation_stats: pocket_core::kernel::framebuffer::PresentationStats,
    pub width: u32,
    pub height: u32,
    pub rgba: Vec<u8>,
}

impl FrameSnapshot {
    pub(crate) fn from_framebuffer(fb: &pocket_core::kernel::Framebuffer) -> Self {
        Self {
            presentation_stats: fb.presentation_stats.clone(),
            width: fb.width,
            height: fb.height,
            rgba: fb.snapshot_rgba8888(),
        }
    }

    fn from_framebuffer_into(fb: &pocket_core::kernel::Framebuffer, scratch: &mut Vec<u8>) -> Self {
        fb.snapshot_rgba8888_into(scratch);
        Self {
            presentation_stats: fb.presentation_stats.clone(),
            width: fb.width,
            height: fb.height,
            rgba: std::mem::take(scratch),
        }
    }
}

/// Kotlin → emulator command. Mirrors `pocket_desktop::runner::InputCommand`.
#[derive(Debug, Clone, Copy)]
pub enum InputCommand {
    Input(InputEvent),
    Stop,
}

/// Shared between the worker thread and the UI thread for the
/// lifetime of one game session.
pub(crate) struct SessionState {
    stop_all: Arc<AtomicBool>,
    /// Latest framebuffer the guest produced. The polling loop on
    /// the UI thread drains this slot and paints it; a write
    /// overwrites whatever was there because the UI only ever
    /// cares about the newest frame.
    latest_frame: Mutex<Option<FrameSnapshot>>,
    presentation_stats: Mutex<Option<pocket_core::kernel::framebuffer::PresentationStats>>,
    gps_notice: Mutex<Option<(f64, f64)>>,
    dependency_notices: Mutex<std::collections::VecDeque<String>>,
    /// `true` while the worker thread is still running. Flipped to
    /// `false` exactly once, just before the worker returns.
    running: Mutex<bool>,
    /// Final summary string. Populated by the worker right before
    /// it exits; read by [`finish`] after the join.
    summary: Mutex<Option<String>>,
    /// Pull handle on the guest's mixed PCM, published by the worker
    /// once the emulator exists. Android has no cpal device, so the
    /// Kotlin side drains this from an `AudioTrack` feeder thread
    /// instead of the kernel pushing to a host stream.
    audio: Mutex<Option<pocket_core::kernel::AudioTap>>,
}

impl SessionState {
    fn new() -> Self {
        Self {
            stop_all: Arc::new(AtomicBool::new(false)),
            latest_frame: Mutex::new(None),
            presentation_stats: Mutex::new(None),
            gps_notice: Mutex::new(None),
            dependency_notices: Mutex::new(Default::default()),
            running: Mutex::new(true),
            summary: Mutex::new(None),
            audio: Mutex::new(None),
        }
    }
}

/// Owned by Kotlin via a `Box::into_raw`'d pointer.
pub struct Session {
    state: Arc<SessionState>,
    input_tx: Sender<InputCommand>,
    worker: Option<JoinHandle<()>>,
}

impl Session {
    pub fn poll_dependency_notice(&self) -> Option<String> {
        self.state.dependency_notices.lock().ok()?.pop_front()
    }
    pub fn poll_gps_notice(&self) -> Option<(f64, f64)> {
        self.state.gps_notice.lock().ok()?.take()
    }
    /// Move the latest framebuffer out of the shared slot.
    pub fn poll_frame(&self) -> Option<FrameSnapshot> {
        self.state
            .latest_frame
            .lock()
            .ok()
            .and_then(|mut g| g.take())
    }

    /// Copy up to `dst.len()` interleaved 16-bit samples out of the
    /// guest's mixer queue.
    pub fn poll_audio(&self, dst: &mut [i16]) -> usize {
        let guard = match self.state.audio.lock() {
            Ok(g) => g,
            Err(_) => return 0,
        };
        guard.as_ref().map_or(0, |tap| tap.drain_into(dst))
    }

    /// `(sample_rate, channels)` the guest opened its output with.
    pub fn audio_format(&self) -> Option<(u32, u16)> {
        let guard = self.state.audio.lock().ok()?;
        let tap = guard.as_ref()?;
        if !tap.format_ready() {
            return None;
        }
        let fmt = tap.guest_format();
        Some((fmt.sample_rate, fmt.channels))
    }

    pub fn send_input(&self, cmd: InputCommand) {
        // The receiver only goes away after the worker exits, in
        // which case we don't care about the input anymore.
        let _ = self.input_tx.send(cmd);
    }

    pub fn request_stop(&self) {
        self.state.stop_all.store(true, Ordering::Release);
        self.send_input(InputCommand::Stop);
    }

    pub fn presentation_fps(&self) -> Option<f32> {
        self.state.presentation_stats.lock().ok()?.as_ref()?.fps()
    }

    pub fn is_running(&self) -> bool {
        self.state.running.lock().map(|g| *g).unwrap_or(false)
    }

    /// Join the worker thread (with a stop signal already sent) and
    /// return the textual summary captured while it was running.
    pub fn finish(mut self) -> String {
        // Belt-and-braces: ask the worker to stop in case the
        // caller forgot to.
        self.request_stop();
        if let Some(handle) = self.worker.take() {
            let _ = handle.join();
        }
        self.state
            .summary
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .unwrap_or_else(|| "(no summary captured)".to_string())
    }
}

/// Spawn the worker thread that drives the emulator for a single
/// game. The returned `Session` is the handle Kotlin holds.
pub fn start(library_root: PathBuf, game_id: String) -> anyhow::Result<Session> {
    let lib = Library::open(&library_root).context("Library::open")?;
    let entry = lib
        .get(&game_id)
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("unknown game id {game_id}"))?;

    let state = Arc::new(SessionState::new());
    let (input_tx, input_rx) = channel::<InputCommand>();

    let state_for_worker = Arc::clone(&state);
    let worker = std::thread::Builder::new()
        .name(format!("pockethle-emu-{game_id}"))
        .spawn(move || {
            let summary =
                run_game_to_completion(&library_root, &entry, &state_for_worker, input_rx);
            if let Ok(mut slot) = state_for_worker.summary.lock() {
                *slot = Some(summary);
            }
            if let Ok(mut running) = state_for_worker.running.lock() {
                *running = false;
            }
        })
        .context("spawn pockethle worker thread")?;

    Ok(Session {
        state,
        input_tx,
        worker: Some(worker),
    })
}

/// Runs the emulator from start to finish, returning a summary
/// suitable for the UI's status panel. Streams framebuffers and
/// drains UI input via [`SessionHook`].
fn run_game_to_completion(
    library_root: &std::path::Path,
    entry: &GameEntry,
    state: &Arc<SessionState>,
    input_rx: Receiver<InputCommand>,
) -> String {
    let card_root = entry.gizmondo_card_root(library_root);
    let mut hook = SessionHook::new(Arc::clone(state), input_rx);
    run_process(
        library_root,
        entry,
        &card_root,
        None,
        None,
        None,
        None,
        &mut hook,
    )
    .0
}

#[derive(Clone)]
struct LaunchContext {
    library_root: PathBuf,
    entry: GameEntry,
    card_root: PathBuf,
}

struct ProcessStartup {
    ack: Option<Sender<Result<(), u32>>>,
    table: HandleTable,
    command_line: String,
    error: u32,
}
impl Drop for ProcessStartup {
    fn drop(&mut self) {
        if let Some(ack) = self.ack.take() {
            let _ = ack.send(Err(self.error));
        }
    }
}
struct ChildJob {
    table: HandleTable,
    thread: JoinHandle<(String, u32)>,
}

fn run_process(
    library_root: &std::path::Path,
    entry: &GameEntry,
    card_root: &std::path::Path,
    guest_path: Option<&str>,
    inherited_ram: Option<MemoryDivision>,
    handle_context: Option<ProcessHandleContext>,
    mut startup: Option<ProcessStartup>,
    hook: &mut SessionHook,
) -> (String, u32) {
    let state = Arc::clone(&hook.state);
    let mut summary_lines = vec![
        format!("Game: {}", entry.display_name),
        format!("Backend: {}", entry.settings.cpu_backend.label()),
    ];
    let exe = if guest_path.is_some() {
        entry.executable_path(library_root)
    } else {
        entry.launch_path(library_root)
    };
    let image = pocket_core::pe::load_file(&exe);
    let machine = image
        .as_ref()
        .map(|image| image.machine)
        .unwrap_or(pocket_core::pe::machine::ARM);
    summary_lines.push(format!("Executable: {}", exe.display()));

    // Managed .NET Compact Framework images cannot run on the native
    // emulation path: there is no CLR to interpret the IL, so the
    // emulator would sit on a black frame forever. The desktop CLI
    // (pocket-cli) runs these through a host .NET runtime instead —
    // tell the user instead of leaving them on a black screen.
    if let Ok(image) = &image {
        if let Some(runtime) = &image.managed_runtime {
            let screen = entry.settings.screen.resolve_image(Some(image));
            if guest_path.is_none() && crate::managed_game::supports(&exe) {
                summary_lines.push(
                    "Managed image: using the Android vAlienAttack compatibility renderer."
                        .to_string(),
                );
                summary_lines.push(format!("Screen: {}x{}", screen.0, screen.1));
                let renderer_summary =
                    crate::managed_game::run(&exe, &state, hook.take_input_receiver(), screen);
                return (
                    format!("{}\n{renderer_summary}", summary_lines.join("\n")),
                    0,
                );
            }
            summary_lines.push(format!(
                "Managed image: CLR metadata {runtime} (.NET Compact Framework). Android has no general CLR backend for this title."
            ));
            return (summary_lines.join("\n"), 0xc0000135);
        }
    }

    // Same Stub→Unicorn promotion logic as `pocket_desktop::runner`:
    // a user who clicks "Run" wants the real ARM core regardless of
    // what is persisted in their library.json.
    let requested_backend = entry.settings.cpu_backend;
    let mut effective_backend = requested_backend;
    let mut emu = match requested_backend {
        CpuBackendPref::Unicorn => match build_unicorn_for_machine(machine) {
            Ok(emu) => emu,
            Err(e) => {
                summary_lines.push(format!("Unicorn unavailable: {e}"));
                return (summary_lines.join("\n"), 0xc0000135);
            }
        },
        CpuBackendPref::Stub => match build_unicorn_for_machine(machine) {
            Ok(emu) => {
                summary_lines.push(
                    "Saved CPU backend was Stub (trace-only); promoting to \
                     Unicorn so the game can actually execute."
                        .to_string(),
                );
                effective_backend = CpuBackendPref::Unicorn;
                emu
            }
            Err(e) => return (format!("Unicorn unavailable: {e}"), 0xc0000135),
        },
    };
    summary_lines.push(format!("Effective backend: {}", effective_backend.label()));

    emu.set_frame_rate_limit(entry.settings.frame_rate_limit.fps());
    emu.max_slices = entry.settings.max_slices;
    emu.instruction_budget_per_slice = entry.settings.instructions_per_slice;

    if let Err(e) = emu.load_pe(&exe) {
        summary_lines.push(format!("load_pe failed: {e:#}"));
        return (summary_lines.join("\n"), 0xc0000135);
    }

    let is_gizmondo = is_gizmondo_game(entry, library_root);
    emu.set_pocket_pc_input(!is_gizmondo);
    emu.set_gizmondo_audio_compatibility(is_gizmondo);
    if let Some(process) = emu.process_mut() {
        process.state.touch_steering.enabled = !is_gizmondo
            && (entry.settings.controls_mode() == pocket_library::stylus_grid::ControlsMode::Zones);
    }
    if !is_gizmondo {
        let state = Arc::clone(&hook.state);
        emu.configure_pocketpc_dependencies(library_root, move |message| {
            if let Ok(mut notices) = state.dependency_notices.lock() {
                notices.push_back(message);
            }
        });
    }
    if is_gizmondo {
        if let Ok(image) = &image {
            crate::colors_trace::install(&mut emu, image);
        }
    }
    if let Some(context) = handle_context {
        context.table.defer_process_exit();
        emu.process_mut()
            .unwrap()
            .state
            .attach_handle_context(context);
    }
    let ram = inherited_ram.or_else(|| is_gizmondo.then(MemoryDivision::gizmondo_sdk_default));
    if !emu.set_memory_division(ram) {
        if let Some(startup) = startup.as_mut() {
            startup.error = 8;
        }
        summary_lines.push("Insufficient device RAM to load process".to_string());
        return (summary_lines.join("\n"), 0xc0000135);
    }
    if !is_gizmondo {
        if let Err(error) = emu.configure_pocketpc_storage(library_root) {
            if let Some(startup) = startup.as_mut() {
                startup.error = 29;
            }
            return (format!("Cannot initialize PocketPC storage: {error:#}"), 29);
        }
    }
    let registry_path = library_root.join(if is_gizmondo {
        "registry-gizmondo.json"
    } else {
        "registry-pocketpc.json"
    });
    let launcher_config = pocket_library::Library::open(library_root)
        .map(|l| l.config().clone())
        .unwrap_or_default();
    if !is_gizmondo {
        if let Err(error) = emu.set_pocketpc_processor(&launcher_config.pocketpc_processor) {
            log::warn!("{error}; using default PXA270 identity");
            let _ = emu.set_pocketpc_processor("pxa270");
        }
    }
    emu.set_gpu_renderer(
        entry
            .settings
            .gpu_renderer
            .unwrap_or(launcher_config.gpu_renderer),
    );
    emu.set_anisotropic_filtering(
        entry
            .settings
            .anisotropic_filtering
            .unwrap_or(launcher_config.anisotropic_filtering),
    );
    emu.set_unimplemented_api_sink(Box::new(crate::unimplemented_log::UnimplementedLog::new(
        library_root.join("pockethle-unimplemented.log"),
        entry.display_name.clone(),
        exe.display().to_string(),
        Arc::new(std::sync::atomic::AtomicBool::new(
            launcher_config.log_unimplemented_apis,
        )),
    )));
    log::set_max_level(match launcher_config.verbosity {
        0 => log::LevelFilter::Warn,
        1 => log::LevelFilter::Info,
        2 => log::LevelFilter::Debug,
        _ => log::LevelFilter::Trace,
    });
    let hardware = (
        launcher_config.bluetooth_enabled,
        launcher_config.camera_enabled,
        launcher_config.gps_enabled,
    );
    if let Some(process) = emu.process_mut() {
        if pocket_library::is_colors_game(entry, library_root) {
            process
                .state
                .vfs
                .set_colors_language(pocket_library::colors_launch_language(
                    entry,
                    library_root,
                    &launcher_config.colors_language,
                ));
        }
        hook.colors_random_gps = if pocket_library::is_colors_game(entry, library_root)
            && launcher_config.gps_fixed_enabled
            && launcher_config.gps_fixed_random
        {
            Some(launcher_config.clone())
        } else {
            None
        };
        process.state.vfs.bluetooth.service.set_allowed(hardware.0);
        process.state.vfs.camera_service().set_allowed(hardware.1);
        process.state.vfs.gps_service().set_allowed(hardware.2);
        if pocket_library::is_colors_game(entry, library_root) && launcher_config.gps_fixed_enabled
        {
            let gps = process.state.vfs.gps_service();
            if let Err(e) = gps.set_fixed_position(launcher_config.simulated_gps_position()) {
                return (format!("Invalid fixed GPS coordinates: {e}"), 0xc000000d);
            }
            gps.set_allowed(true);
            log::info!("GPS1 fixed simulation activated on Android");
        }
        let registry_result = (|| {
            process
                .state
                .registry
                .configure_persistence(&registry_path)?;
            if is_gizmondo && guest_path.is_none() {
                process.state.registry.reset_gizmondo_backlight()?;
                process.state.sync_backlight();
            }
            Ok::<(), std::io::Error>(())
        })();
        if let Err(e) = registry_result {
            summary_lines.push(format!("Cannot initialize device registry: {e}"));
            return (summary_lines.join("\n"), 0xc0000135);
        }
        let (preset, platform) = launcher_config.device_identity_hex(is_gizmondo);
        if let Err(e) = pocket_core::kernel::device_identity::DeviceIdentity::configure(
            &mut process.state.registry,
            preset,
            platform,
        ) {
            summary_lines.push(format!("Invalid device identity: {e}"));
            return (summary_lines.join("\n"), 0xc000000d);
        }
        if is_gizmondo {
            process
                .state
                .internet
                .set_gprs_enabled(launcher_config.gprs_enabled);
            if let Err(e) = pocket_core::kernel::colors::configure(
                &mut process.state,
                if pocket_library::is_colors_game(entry, library_root) {
                    &launcher_config.colors_server_url
                } else {
                    ""
                },
                &launcher_config.colors_terminal_id,
            ) {
                summary_lines.push(e);
                return (summary_lines.join("\n"), 0xc0000135);
            }
        }
    }
    if !is_gizmondo {
        if let Err(error) = emu.set_pocketpc_identity(
            &entry.settings.pocketpc_owner_name,
            &entry.settings.pocketpc_device_name,
            &entry.settings.pocketpc_device_id,
        ) {
            summary_lines.push(format!("Invalid PocketPC identity: {error}"));
            return (summary_lines.join("\n"), 87);
        }
    }
    for value in &entry.registry {
        let registry_value = if let Some(text) = value.string.as_deref() {
            pocket_core::kernel::registry::RegistryValue::Sz(text.to_string())
        } else if let Some(number) = value.dword {
            pocket_core::kernel::registry::RegistryValue::Dword(number)
        } else {
            continue;
        };
        let saved = emu
            .process()
            .and_then(|p| p.state.registry.value(&value.key, &value.name));
        if saved.is_none() || value.name.eq_ignore_ascii_case("InstallDir") {
            emu.set_registry_value(&value.key, &value.name, registry_value);
        }
    }

    // The tap has to be published before the guest runs: the Kotlin
    // feeder thread starts polling as soon as the surface is up.
    if guest_path.is_none() {
        if let Ok(mut slot) = state.audio.lock() {
            *slot = emu.audio_tap();
        }
    }
    emu.start_audio();
    let (screen_width, screen_height) = if is_gizmondo {
        (320, 240)
    } else {
        entry.settings.screen.resolve_image(image.as_ref().ok())
    };
    emu.set_screen_size(screen_width, screen_height);
    summary_lines.push(format!("Screen: {screen_width}x{screen_height}"));
    let extracted = entry.extracted_dir(library_root);

    emu.mount_read_only_dir("\\Application\\", &extracted);
    emu.mount_read_only_dir("\\Program Files\\", &extracted);
    emu.mount_read_only_dir("\\Program Files\\Game\\", &extracted);
    if is_gizmondo {
        let flash_disk = entry.gizmondo_flash_dir(library_root);
        emu.mount_save_dir("\\Flash Disk\\", &flash_disk);
        summary_lines.push(format!(
            "Mounted Gizmondo Flash Disk at {}",
            flash_disk.display()
        ));
        emu.mount_read_only_dir("\\SD Card\\", card_root);
        emu.mount_read_only_dir("\\Storage Card\\", card_root);
        emu.mount_read_only_dir("\\SD Card\\Game\\", &extracted);
        emu.mount_read_only_dir("\\Storage Card\\Game\\", &extracted);
        summary_lines.push(format!(
            "Mounted Gizmondo SD-card layout at {}",
            extracted.display()
        ));
    }
    for (prefix, directory) in entry.install_mounts(library_root) {
        emu.mount_read_only_dir(&prefix, directory);
    }
    if let Some(paths) = entry.guest_launch_paths(library_root) {
        emu.mount_read_only_dir(
            &paths.install_prefix,
            entry.install_mount_dir(library_root, &paths.install_prefix),
        );
        emu.set_module_path(&paths.module_path);
        emu.set_default_dir(&paths.working_dir);
        let save_dir = entry.save_dir(library_root);
        emu.mount_save_dir(&paths.save_prefix, &save_dir);
        if !is_gizmondo
            && !paths
                .save_prefix
                .trim_end_matches('\\')
                .eq_ignore_ascii_case(r"\My Documents")
        {
            emu.mount_save_dir(r"\My Documents\", save_dir.join("my-documents"));
        }
        summary_lines.push(format!(
            "Save data: {} -> {:?}",
            save_dir.display(),
            paths.save_prefix
        ));
    }
    if !is_gizmondo && entry.source_cab.to_ascii_lowercase().ends_with(".cab") {
        if let Some(install_dir) = entry.install_dir.as_deref() {
            match emu.complete_cab_registry_setup(&extracted, install_dir) {
                Ok(count) if count != 0 => {
                    summary_lines.push(format!("CAB registry setup completed: {count}"))
                }
                Ok(_) => {}
                Err(error) => {
                    log::warn!("CAB registry setup failed: {error:#}");
                    summary_lines.push(format!("CAB registry setup failed: {error:#}"));
                }
            }
        }
    }
    // Keep the executable's directory inside the card, as on desktop. Native
    // DLLs use GetModuleFileName to locate their configuration and assets.
    if is_gizmondo {
        if let Some(guest_exe) = entry.gizmondo_guest_exe_path(library_root) {
            emu.set_module_path(&guest_exe);
            if let Some((directory, _)) = guest_exe.rsplit_once('\\') {
                emu.set_default_dir(&format!("{directory}\\"));
            }
            log::info!("Gizmondo module path: {guest_exe}");
            summary_lines.push(format!("Module path: {guest_exe}"));
        }
    }
    // Match the desktop GUI: a real user is in the loop, so don't
    // auto-fire WM_QUIT after a fixed number of synthetic messages.
    emu.set_synthetic_message_budget(0);

    if let Some(guest_path) = guest_path {
        emu.set_module_path(guest_path);
        if let Some((directory, _)) = guest_path.rsplit_once('\\') {
            emu.set_default_dir(&format!("{directory}\\"));
        }
    }
    let kernel = &mut emu.process_mut().unwrap().state;
    kernel.process_launch_enabled = true;
    hook.pid = kernel.object_handles.process_id();
    hook.launch_context = Some(LaunchContext {
        library_root: library_root.to_path_buf(),
        entry: entry.clone(),
        card_root: card_root.to_path_buf(),
    });
    if let Some(startup) = startup.as_mut() {
        if let Err(error) = emu.set_startup_command_line(&startup.command_line) {
            startup.error = 8;
            return (
                format!("Cannot initialize child command line: {error:#}"),
                0xc0000017,
            );
        }
        if let Some(ack) = startup.ack.take() {
            let _ = ack.send(Ok(()));
        }
        // Commit PROCESS_INFORMATION before any child instruction can execute.
        while !startup.table.start_allowed() && !hook.stop_all.load(Ordering::Acquire) {
            std::thread::sleep(Duration::from_millis(1));
        }
        if hook.stop_all.load(Ordering::Acquire) {
            emu.process_mut().unwrap().state.should_stop = true;
        }
    }
    let run_result = emu.run_with_hook(hook);
    match &run_result {
        Ok(()) => summary_lines.push("Emulator exited cleanly.".to_string()),
        Err(e) => summary_lines.push(format!("Emulator stopped: {e:#}")),
    }
    emu.stop_audio();
    if let Some(process) = emu.process() {
        if let Err(e) = process.state.registry.flush() {
            summary_lines.push(format!("Cannot save device registry: {e}"));
            log::error!("Cannot save device registry: {e}");
        }
    }

    // Push one last framebuffer so the UI ends up showing whatever
    // the guest left on screen even if it stopped between frames.
    if let Some(p) = emu.process() {
        if !p.state.framebuffer.is_all_black() {
            if hook.foreground.load(Ordering::Acquire) == hook.pid {
                push_frame(
                    &state,
                    FrameSnapshot::from_framebuffer(&p.state.presentation_framebuffer()),
                );
            }
        }
    }

    let code = if run_result.is_ok() {
        emu.process()
            .and_then(|p| p.state.process_exit_code)
            .unwrap_or(0)
    } else {
        0xc0000005
    };
    // RAMTEST's orphan waits for its parent while remaining alive itself.
    // Refund private RAM and publish parent completion BEFORE joining children.
    let table = emu.process().map(|p| p.state.object_handles.clone());
    drop(emu);
    if let Some(table) = table {
        table.complete_process_exit(code);
    }
    hook.finish_children();
    (summary_lines.join("\n"), code)
}

#[cfg(feature = "unicorn")]
fn build_unicorn_for_machine(machine: u16) -> anyhow::Result<Emulator> {
    if matches!(
        machine,
        pocket_core::pe::machine::MIPS_R3000 | pocket_core::pe::machine::MIPS_R4000
    ) {
        Emulator::with_unicorn_cpu_for_arch(pocket_core::cpu::Arch::Mips)
    } else {
        Emulator::with_unicorn_cpu()
    }
}

#[cfg(not(feature = "unicorn"))]
fn build_unicorn_for_machine(_machine: u16) -> anyhow::Result<Emulator> {
    Err(anyhow::anyhow!(
        "binary was not compiled with the `unicorn` feature"
    ))
}

pub(crate) fn push_frame(state: &Arc<SessionState>, frame: FrameSnapshot) {
    if let Ok(mut stats) = state.presentation_stats.lock() {
        *stats = Some(frame.presentation_stats.clone());
    }
    if let Ok(mut slot) = state.latest_frame.lock() {
        *slot = Some(frame);
    }
}

/// Bridges the UI thread (Kotlin) and the running emulator on the
/// worker thread.
struct SessionHook {
    colors_random_gps: Option<pocket_library::LauncherConfig>,
    geofence_down: bool,
    state: Arc<SessionState>,
    input_rx: Arc<Mutex<Receiver<InputCommand>>>,
    stop_all: Arc<AtomicBool>,
    foreground: Arc<AtomicU32>,
    pid: u32,
    children: Vec<ChildJob>,
    launch_context: Option<LaunchContext>,
    last_frame: u64,
    input_disconnected: bool,
    last_emit_at: Option<Instant>,
    scratch: Vec<u8>,
    saw_non_black: bool,
}

impl SessionHook {
    fn queue_input(
        &mut self,
        ev: InputEvent,
        gps: &pocket_core::kernel::gps::Service,
        pending: &mut std::collections::VecDeque<InputEvent>,
    ) {
        match ev {
            InputEvent::KeyDown { vk: 0x73 } => {
                if !self.geofence_down {
                    if let Some(config) = self.colors_random_gps.as_ref() {
                        if let Some(position) = config.simulated_gps_position() {
                            if gps.set_fixed_position(Some(position)).is_ok() {
                                if let Ok(mut slot) = self.state.gps_notice.lock() {
                                    *slot = Some(position);
                                }
                            }
                        }
                    }
                }
                self.geofence_down = true;
            }
            InputEvent::KeyUp { vk: 0x73 } => self.geofence_down = false,
            _ => {}
        }
        // The simulator action supplements, rather than consumes, the hardware key.
        pending.push_back(ev);
    }

    fn run_pending_child(&mut self, state: &mut KernelState) {
        let Some(request) = state.pending_process_launch.take() else {
            return;
        };
        let context = self.launch_context.clone();
        let relative = context.as_ref().and_then(|context| {
            let child = request.executable.canonicalize().ok()?;
            // CreateProcess uses a path already resolved through the guest VFS.
            // SDCreateProcess keeps its validated foreground card restriction.
            if request.concurrent {
                return Some(
                    context
                        .entry
                        .child_executable_reference(&context.library_root, &child),
                );
            }
            let root = context.card_root.canonicalize().ok()?;
            if !child.starts_with(root) {
                return None;
            }
            let game_dir = context
                .library_root
                .join(context.entry.relative_dir())
                .canonicalize()
                .ok()?;
            child.strip_prefix(game_dir).ok().map(PathBuf::from)
        });
        if request.concurrent {
            let result = if let (Some(context), Some(relative)) = (context, relative) {
                let mut child_game = context.entry.clone();
                child_game.executable = relative;
                let handle_context = state.child_handle_context(request.process_handle).unwrap();
                let table = handle_context.table.clone();
                let child_table = table.clone();
                let parent_pid = self.pid;
                let foreground = self.foreground.clone();
                let mut child_hook = self.child_hook();
                let ram = state.memory_division.clone();
                let command_line = request.command_line.clone();
                let guest_path = request.guest_path.clone();
                let (ready_tx, ready_rx) = std::sync::mpsc::channel();
                let startup = ProcessStartup {
                    ack: Some(ready_tx),
                    table: child_table.clone(),
                    command_line,
                    error: 193,
                };
                let spawned = std::thread::Builder::new()
                    .name(format!("pockethle-process-{}", table.process_id()))
                    .spawn(move || {
                        let result = run_process(
                            &context.library_root,
                            &child_game,
                            &context.card_root,
                            Some(&guest_path),
                            ram,
                            Some(handle_context),
                            Some(startup),
                            &mut child_hook,
                        );
                        child_table.complete_process_exit(result.1);
                        if child_table
                            .exit_code(child_table.process_id(), Some(0))
                            .is_none()
                        {
                            child_table.set_exit(Some(0), result.1);
                        }
                        child_table.mark_inactive();
                        let next = child_table.focus_after_exit(parent_pid);
                        let _ = foreground.compare_exchange(
                            child_table.process_id(),
                            next,
                            Ordering::AcqRel,
                            Ordering::Acquire,
                        );
                        result
                    });
                match spawned {
                    Ok(thread) => {
                        self.children.push(ChildJob {
                            table: table.clone(),
                            thread,
                        });
                        match ready_rx.recv_timeout(Duration::from_secs(30)) {
                            Ok(Ok(())) => {
                                self.foreground.store(table.process_id(), Ordering::Release);
                                Ok(request.process_handle)
                            }
                            Ok(Err(error)) => Err(error),
                            Err(_) => {
                                table.terminate_remote_process(table.process_id(), 0xc0000001);
                                table.allow_start();
                                Err(1460)
                            }
                        }
                    }
                    Err(_) => {
                        table.set_exit(None, 0xc0000017);
                        table.mark_inactive();
                        Err(8)
                    }
                }
            } else {
                if let Some(table) = state.object_handles.child(request.process_handle) {
                    table.mark_inactive();
                }
                Err(5)
            };
            state
                .process_launch_results
                .insert(request.call_key, result);
            return;
        }
        let mut exit_code = 0xc0000135;
        if let (Some(context), Some(relative)) = (context, relative) {
            let mut child_game = context.entry.clone();
            child_game.executable = relative;
            state.audio.suspend_output();
            let saved = pocket_core::suspend_host_session();
            let mut child_hook = self.child_hook();
            let child_pid = state
                .object_handles
                .child_id(request.process_handle)
                .unwrap();
            self.foreground.store(child_pid, Ordering::Release);
            log::info!("parent suspended; entering child {}", request.guest_path);
            let (outcome, code) = run_process(
                &context.library_root,
                &child_game,
                &context.card_root,
                Some(&request.guest_path),
                state.memory_division.clone(),
                state.child_handle_context(request.process_handle),
                None,
                &mut child_hook,
            );
            exit_code = code;
            self.foreground.store(self.pid, Ordering::Release);
            self.input_disconnected = child_hook.input_disconnected;

            // run_process has dropped its child Emulator and its media first.
            drop(saved);
            state.audio.resume_output();
            log::info!("child finished with code 0x{exit_code:08x}; resuming preserved parent");
            if exit_code != 0 {
                log::warn!("child outcome: {}", outcome);
            }
            self.last_frame = 0;
            self.last_emit_at = None;
            self.saw_non_black = false;
            // Repaint the preserved parent frame even if its counter is static.
            state.framebuffer.frame_counter = state.framebuffer.frame_counter.wrapping_add(1);
            state.pending_input.clear();
            if let Some(up) = state.stylus_stick.cancel() {
                state.pending_input.push_back(up);
            }
            state.pressed_keys.fill(false);
            state.held_keys.clear();
            state.key_repeat_next_ms = None;
        } else {
            log::warn!("child launch refused: path outside card or missing runner context");
        }
        if let Some(table) = state.object_handles.child(request.process_handle) {
            table.complete_process_exit(exit_code);
            table.set_exit(Some(0), exit_code);
            table.mark_inactive();
        }
        state.sync_transferred_handles();
        if let Some(child) = state.child_processes.get_mut(&request.process_handle) {
            child.exit_code = Some(exit_code);
        }
        for handle in [request.process_handle, request.thread_handle] {
            if let Some(mut event) = state.events.get_mut(&handle) {
                event.signalled = true;
            }
        }
    }

    fn finish_children(&mut self) {
        for job in self.children.drain(..) {
            if !job.table.start_allowed() {
                job.table
                    .terminate_remote_process(job.table.process_id(), 0xc0000001);
                job.table.allow_start();
            }
            if let Err(_) = job.thread.join() {
                self.stop_all.store(true, Ordering::Release);
            }
        }
    }
    fn reap_children(&mut self) {
        let mut index = 0;
        while index < self.children.len() {
            if self.children[index].thread.is_finished() {
                let job = self.children.swap_remove(index);
                if job.thread.join().is_err() {
                    job.table.complete_process_exit(0xc0000005);
                    job.table.set_exit(Some(0), 0xc0000005);
                    job.table.mark_inactive();
                }
            } else {
                index += 1;
            }
        }
    }

    fn child_hook(&self) -> Self {
        let (_, input_rx) = channel();
        let mut hook = Self::new(Arc::clone(&self.state), input_rx);
        hook.input_rx = Arc::clone(&self.input_rx);
        hook.stop_all = Arc::clone(&self.stop_all);
        hook.foreground = Arc::clone(&self.foreground);
        hook
    }
    fn take_input_receiver(&mut self) -> Receiver<InputCommand> {
        let (_, replacement) = channel();
        Arc::try_unwrap(std::mem::replace(
            &mut self.input_rx,
            Arc::new(Mutex::new(replacement)),
        ))
        .ok()
        .expect("managed root owns its input receiver")
        .into_inner()
        .unwrap()
    }

    fn new(state: Arc<SessionState>, input_rx: Receiver<InputCommand>) -> Self {
        Self {
            colors_random_gps: None,
            geofence_down: false,
            stop_all: Arc::clone(&state.stop_all),
            state,
            input_rx: Arc::new(Mutex::new(input_rx)),
            foreground: Arc::new(AtomicU32::new(1)),
            pid: 1,
            children: Vec::new(),
            launch_context: None,
            last_frame: 0,
            input_disconnected: false,
            last_emit_at: None,
            scratch: Vec::new(),
            saw_non_black: false,
        }
    }
}

impl FrameHook for SessionHook {
    fn on_frame(&mut self, kernel: &mut KernelState) -> FrameAction {
        // Drain any pending UI input into the kernel's queue.
        self.reap_children();
        let mut stop_requested = self.stop_all.load(Ordering::Acquire);
        if !self.input_disconnected && self.foreground.load(Ordering::Acquire) == self.pid {
            let input_rx = Arc::clone(&self.input_rx);
            let input = input_rx.lock().unwrap_or_else(|e| e.into_inner());
            loop {
                match input.try_recv() {
                    Ok(InputCommand::Input(ev)) => {
                        self.queue_input(ev, &kernel.vfs.gps_service(), &mut kernel.pending_input);
                    }
                    Ok(InputCommand::Stop) => stop_requested = true,
                    Err(TryRecvError::Empty) => break,
                    Err(TryRecvError::Disconnected) => {
                        self.input_disconnected = true;
                        break;
                    }
                }
            }
        }

        stop_requested |= self.input_disconnected;
        if stop_requested {
            self.stop_all.store(true, Ordering::Release);
        }
        if !stop_requested {
            self.run_pending_child(kernel);
        }
        stop_requested |= self.stop_all.load(Ordering::Acquire);

        // Stream a fresh framebuffer if the guest produced one.
        if self.foreground.load(Ordering::Acquire) == self.pid {
            if let Ok(mut slot) = self.state.audio.lock() {
                *slot = Some(kernel.audio.tap());
            }
        }
        let counter = kernel.framebuffer.frame_counter;
        if self.foreground.load(Ordering::Acquire) == self.pid && counter != self.last_frame {
            if kernel.framebuffer.is_all_black() && self.saw_non_black {
                return if stop_requested {
                    kernel.should_stop = true;
                    FrameAction::Stop
                } else {
                    FrameAction::Continue
                };
            }
            self.saw_non_black = !kernel.framebuffer.is_all_black();
            let now = Instant::now();
            if let Some(phase) = presentation_phase(self.last_emit_at, now) {
                self.last_frame = counter;
                self.last_emit_at = Some(phase);
                let frame = FrameSnapshot::from_framebuffer_into(
                    &kernel.presentation_framebuffer(),
                    &mut self.scratch,
                );
                push_frame(&self.state, frame);
            }
        }

        if stop_requested {
            kernel.should_stop = true;
            FrameAction::Stop
        } else {
            FrameAction::Continue
        }
    }
}

#[cfg(all(test, feature = "unicorn"))]
#[path = "runner_tests.rs"]
mod tests;

#[cfg(test)]
mod presentation_clock_tests {
    use super::*;

    #[test]
    fn jitter_keeps_phase_and_pause_does_not_create_a_catchup_burst() {
        let base = Instant::now();
        let mut phase = None;
        for ms in [0, 17, 33, 49, 66, 83, 99] {
            phase = Some(presentation_phase(phase, base + Duration::from_millis(ms)).unwrap());
        }
        assert_eq!(phase.unwrap(), base + Duration::from_millis(96));
        assert!(presentation_phase(phase, base + Duration::from_millis(100)).is_none());
        let after_pause = base + Duration::from_millis(1001);
        phase = presentation_phase(phase, after_pause);
        assert!(phase.is_some());
        assert!(presentation_phase(phase, after_pause).is_none());
    }
}

#[cfg(test)]
mod geofence_refresh_tests {
    use super::*;
    use pocket_core::kernel::gps::Service;
    fn coordinates(gps: &Service) -> [u8; 8] {
        gps.open().unwrap().lock().unwrap().packet().unwrap()[21..29]
            .try_into()
            .unwrap()
    }
    #[test]
    fn geofence_adds_one_refresh_per_press_and_preserves_guest_events() {
        let (_, rx) = channel();
        let mut hook = SessionHook::new(Arc::new(SessionState::new()), rx);
        let gps = Service::default();
        gps.set_allowed(true);
        gps.set_fixed_position(Some((12., 34.))).unwrap();
        let original = coordinates(&gps);
        let down = InputEvent::KeyDown { vk: 0x73 };
        let up = InputEvent::KeyUp { vk: 0x73 };
        let mut pending = std::collections::VecDeque::new();
        // Other games and host/manual modes have no random Colors config.
        hook.queue_input(down, &gps, &mut pending);
        hook.queue_input(up, &gps, &mut pending);
        assert_eq!(coordinates(&gps), original);
        let mut config = pocket_library::LauncherConfig::default();
        config.gps_fixed_enabled = true;
        config.gps_fixed_random = true;
        hook.colors_random_gps = Some(config);
        hook.queue_input(down, &gps, &mut pending);
        let refreshed = coordinates(&gps);
        assert_ne!(refreshed, original);
        hook.queue_input(down, &gps, &mut pending);
        assert_eq!(coordinates(&gps), refreshed);
        hook.queue_input(up, &gps, &mut pending);
        assert_eq!(
            pending.into_iter().collect::<Vec<_>>(),
            vec![down, up, down, down, up]
        );
    }
}
