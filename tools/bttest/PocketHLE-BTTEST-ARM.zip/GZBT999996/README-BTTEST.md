# PocketHLE BTTEST ARM

Importer ce ZIP dans la librairie comme un jeu Gizmondo, puis lancer BTTEST
(identifiant `GZBT999996`). Aucun rebuild de l’émulateur n’est nécessaire si
le patch Bluetooth/manette et le correctif d’activation caméra sont installés.

Avant de lancer : activer **Settings → Emulator options → Bluetooth hardware
(Classic / RFCOMM)** et le Bluetooth dans Windows ou Android. Pour découvrir
un nouvel appareil, le mettre en mode détectable/appairage. Android demande
les permissions Bluetooth nécessaires au lancement du jeu.

Le programme ARM utilise le chemin SDK : `BT_MSG`, `WSAStartup`,
`WSALookupServiceBeginW`, `WSALookupServiceNextW`, `WSALookupServiceEnd`,
`WSACleanup`. La recherche peut prendre une dizaine de secondes. Le test
affiche les douze premiers noms et adresses et écrit le rapport UTF-8 complet
dans `flash/bttest.txt` de la librairie (nom guest `\Flash Disk\BTTEST.TXT`).
La liste est limitée à 64 périphériques ; une limite atteinte est signalée.
Les noms du rapport sont limités à 128 caractères et marqués `...` au-delà.

Le rapport contient le nom de l’hôte, les étapes PASS/FAIL, les erreurs en
décimal et hexadécimal, les périphériques et `DEVICE_COUNT`.
`BTTEST_RESULT PASS` avec `DEVICE_COUNT 0` signifie que la recherche a abouti
mais n’a pas trouvé de périphérique. Une liste vide ne simule pas une panne.

La recherche porte sur **Bluetooth Classic** : appareils appairés/mémorisés
et appareils détectables remontés par le backend. Les appareils mémorisés
peuvent être absents ou éteints. Ce test ne recherche pas le BLE, n’énumère pas
les services SDP, n’appaire aucun appareil et n’ouvre aucune connexion RFCOMM.

Repères d’erreurs :

- `10091` : service Bluetooth non prêt ; vérifier l’option, la radio et le pilote.
- `10013` : accès refusé, notamment permissions Android.
- `10110` / `10102` : fin normale de la liste, traitée comme un succès.
- Une autre erreur est conservée telle que renvoyée par le backend.

Le scan ferme sa recherche et Winsock avant le dialogue final. Relancer le
test refait la recherche et remplace uniquement son propre `BTTEST.TXT`.

Validation : exécution ARM réelle avec Unicorn, backend synthétique : trois
périphériques, noms Unicode et longs, liste vide, refus d’accès et service
désactivé. Les adresses et erreurs du rapport ont été vérifiées. Le scan sur
une radio physique reste à valider chez l’utilisateur.

Sources indépendantes du SDK propriétaire incluses dans `source`. Pour
reconstruire avec Python, Clang et LLD depuis ce dossier :

```text
python build.py --clang clang --lld ld.lld
```
